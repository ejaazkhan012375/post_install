#!/bin/sh

# ###VARS###
InstallMethod=NFS
swdProduct=qrd73000
swdLang=us
swdCust=csp
repos=/swdist/repos
swdPkgLvl=0
swdOS=lin
esdStdVer=13
instType=install
iplType=iplno
swdWorkDir=/esd/sdwork/qrd73000/us/0
swdWorkDirMain=/esd/sdwork
swdDistDir=/esd/swd
pkgAssetTagFile=/var/.SWDist_Sig/OSPESDAssetTag.pkg
assetTagFile=/var/.SWDist_Sig/OSPESDAssetTag
esdSigFileName=qrd73000_us_0.csplin.swidtag
ESDMount=
imgDir=$ESDMount$swdDistDir/$swdProduct/img/$swdLang
rspDir=$swdDistDir/$swdProduct/rsp/$swdLang
pkgDir=$ESDMount$swdDistDir/$swdProduct/pkg/$swdLang/$swdPkgLvl
swdRebootAfter=n
swdUninstall=n
swdIncludeImg=y
swdLocalInst=N
swdBundle=n
swdCleanup=y
swdSpcChk=all
swdOSVerChk=all
swdVerifyChk=all
swdCurVerChk=all
# ###END_VARS###

translation_date=`date +%D`
translation_time=`date +%T`
translation_target=`hostname`

mkdir -p -m 755 /var/.SWDist_Sig 2>&1
swdLocalInst="$(echo "$swdLocalInst" |tr 'a-z' 'A-Z')"
InstallMethod="$(echo "$InstallMethod" |tr 'a-z' 'A-Z')"
if [[ $swdLocalInst = "Y" ]]; then
   if [[ $InstallMethod != "LOCAL" ]]; then
      mkdir -p $rspDir
      cp -r $pkgDir $rspDir/pkg
      cp -r $imgDir $rspDir/img
      newPkg=$rspDir/pkg
      newImg=$rspDir/img
      pkgDir=$newPkg
      imgDir=$newImg
   fi
fi

cp $pkgDir/$esdSigFileName /var/.SWDist_Sig/$esdSigFileName 2>&1
chmod 775 /var/.SWDist_Sig/$esdSigFileName 2>&1

echo ^^^$translation_target^^^$translation_date^^^$translation_time>> $assetTagFile

if [[ -s $pkgAssetTagFile ]]
then
   rm $pkgAssetTagFile 2>&1
fi

$swdWorkDir/translation_cscript.sh $swdWorkDir/$swdProduct.env $swdWorkDir $swdDistDir $imgDir $rspDir $pkgDir $instType $swdRebootAfter $swdUninstall $swdBundle $swdCleanup

status=$?

cp $swdWorkDir/$swdProduct*.log $swdWorkDirMain/.
