#!/bin/sh
# ************************************************************************* #
# Licensed Materials - Property of IBM
#
# � Copyright IBM Corp. 2000, 2011     All Rights Reserved
# ************************************************************************* #


# ************************************************************************* #
# COMMIT SCRIPT FOR LINUX
# ************************************************************************* #
# ESD Standard Version 12
# ************************************************************************* #
# Modifications
# 02/27/2006 - Initial Release - Changed Architecture
# 06/26/2006 - Added _ESDCS to the name of each function because like function
#              names in the install scripts were causing problems.
# 09/15/2006 - Rearranged location of force case of a few variables.
# 05/08/2007 - Updated to allow for more that 10 input params 10+
#              Will come in as key^^^value pairs.
# 07/30/2007 - Added code for SD-TSA requirements giving new functionality
#              to allow for space checking without installing using utils pkg
# 09/27/2007 - Added code to ignore case on DistOnly var
# 11/12/2009 - Modified df command.
# 04/28/2010 - Modified Cleanup
# 09/08/2010 - Added COMPUTERNAME/HOSTNAME echo at the end of the logging.
# 09/09/2010 - Added new return codes and updated old ones.
# 10/21/2010 - Added new code to support swdCurVer function.
# 03/15/2011 - Modified Reboot code to print proper ERROR message format.
# ************************************************************************* #


# ************************************************************************* #
# Return Codes:
#   0:  SUCCESS
#   1:  NOT ENOUGH DIST SPACE
#   2:  NOT ENOUGH INST SPACE
#   3:  ALREADY INSTALLED
#   5:  INSTALL SCRIPT FAILURE
#   6:  PRE-INSTALLATION CONFIGURATION FAILURE
#   7:  POST-INSTALLATION CONFIGURATION FAILURE
#   8:  PRE-REQUISITE NOT PRESENT
#   9:  UNABLE TO CREATE/MOUNT FILESYSTEM
#  11:  UNABLE TO INSTALL/DISTRIBUTE FILES
#  20:  SHUTDOWN FAILED
# ************************************************************************* #


# ********** VARIABLE DECLARATIONS ********************************
  # initialize return code
    csrc=0

  # set path
    PATH=$PATH:/usr/sbin:/usr/local/sbin
# ********** END VARIABLE DECLARATIONS ****************************


# ********** FUNCTION DEFINITIONS *********************************
  # End Program Function
    function GOTO_END_ESDCS
    {
      csrc=$1

      echo . >> $swdPkgLog
      echo "Date/Time COMMIT script completed on `hostname`:" >> $swdPkgLog
      date >> $swdPkgLog
      echo --------------------------------------------------------- >> $swdPkgLog
      exit $csrc
    }


  # Cleanup $swdDistDir Filesystem
    function CLEANUP_ESDCS
    {
      if [[ "$swdCleanup" = "YES" ]] || [[ "$swdCleanup" = "Y" ]]
      then
        echo . >> $swdPkgLog
        echo "Cleaning up the $swdDistDir/$swdProduct directory..." >> $swdPkgLog
        rm -r $swdDistDir/$swdProduct

        if [[ -d $swdDistDir/lost+found ]]
        then
          echo "Cleaning up the $swdDistDir/lost+found directory..." >> $swdPkgLog
          rm -r $swdDistDir/lost+found/*
        fi

        remains=`ls $swdDistDir`

        if [[ -z $remains ]]
        then
          echo "The $swdDistDir directory is empty." >> $swdPkgLog
          echo "Unmounting $swdDistDir filesystem..." >> $swdPkgLog
          umount $swdDistDir

          #echo "Cleaning up the $swdDistDir directory..." >> $swdPkgLog
          #rm -r $swdDistDir
        else
          echo "The $swdDistDir directory still contains files." >> $swdPkgLog
        fi
      else
        echo .  >> $swdPkgLog
        echo "swdCleanup is set to no; leaving files in $swdDistDir/$swdProduct." >> $swdPkgLog
      fi
    }


  # Mount A Filesystem
    function MOUNT_FS_ESDCS
    {
      fs=$1

      temp=`mount | grep " $fs "`

      if [[ -z $temp ]]
      then
        mount $fs >/dev/null 2>&1
        rc=$?

        if [[ "$rc" != 0 ]]
        then
          echo "ERROR: mounting $fs filesystem." >> $swdPkgLog
          return 1
        else
          echo "$fs filesystem mounted properly." >> $swdPkgLog
        fi
      else
        echo "$fs filesystem is already mounted." >> $swdPkgLog
      fi

      return 0
    }


  # Not Enough DASD to Distribute
    function NO_DIST_SPACE_ESDCS
    {
      echo . >> $swdPkgLog
      echo "ERROR: Insufficient DASD to distribute, need at least $swdDSpace 1024-byte blocks." >> $swdPkgLog
      echo "Distribute aborted: error code 1." >> $swdPkgLog

      CLEANUP_ESDCS
      GOTO_END_ESDCS 1
    }


  # Not Enough DASD to Install
    function NO_INST_SPACE_ESDCS
    {
      echo . >> $swdPkgLog
      echo "ERROR: Insufficient DASD to install, need at least $swdISpace 1024-byte blocks." >> $swdPkgLog
      echo "Distribute aborted: error code 2." >> $swdPkgLog

      CLEANUP_ESDCS
      GOTO_END_ESDCS 2
    }


  # Package is Already Installed
    function ALREADY_INSTALLED_ESDCS
    {
      echo . >> $swdPkgLog
      echo "ERROR: $swdPkgDesc is already installed." >> $swdPkgLog
      echo "Installation aborted: error code 3." >> $swdPkgLog

      CLEANUP_ESDCS
      GOTO_END_ESDCS 3
    }


  # Installation Command Failed
    function INSTALL_FAILED_ESDCS
    {
      echo . >> $swdPkgLog
      echo "ERROR: $swdInstall script returned non-zero." >> $swdPkgLog
      echo "Installation FAILED: error code 5." >> $swdPkgLog

      if [[ "$swdNormalInst" != "Y" ]]
      then
        CLEANUP_ESDCS
      fi
      GOTO_END_ESDCS 5
    }


  # Pre-Installation Failed
    function PRE_INSTALL_FAILED_ESDCS
    {
      echo . >> $swdPkgLog
      echo "ERROR: Pre-installation configuration failed." >> $swdPkgLog
      echo "Installation FAILED: error code 6." >> $swdPkgLog

      CLEANUP_ESDCS
      GOTO_END_ESDCS 6
    }


  # Post-Installation Failed
    function POST_INSTALL_FAILED_ESDCS
    {
      echo . >> $swdPkgLog
      echo "ERROR: Post-installation configuration failed." >> $swdPkgLog
      echo "Installation FAILED: error code 7." >> $swdPkgLog

      CLEANUP_ESDCS
      GOTO_END_ESDCS 7
    }


  # Pre-requisite File Not Found
    function PREREQ_FAILED_ESDCS
    {
      echo . >> $swdPkgLog
      echo "ERROR: Pre-requisite is NOT installed." >> $swdPkgLog
      echo "Installation FAILED: error code 8." >> $swdPkgLog

      CLEANUP_ESDCS
      GOTO_END_ESDCS 8
    }

  # SUCCESS
    function SKIP_INSTALL_ESDCS
    {
      echo . >> $swdPkgLog
      echo "Installation of $swdPkgDesc was BYPASSED." >> $swdPkgLog
      echo "Installation aborted: error code 12." >> $swdPkgLog

      CLEANUP_ESDCS
      GOTO_END_ESDCS 12
    }

  # Unsupported back level version
    function UNSUPPORTED_BCK_LVL_VER_ESDCS
    {
      echo . >> $swdPkgLog
      echo "ERROR: Unsupported back level version was found." >> $swdPkgLog
      echo "Upgrade installation FAILED: error code 17." >> $swdPkgLog

      CLEANUP_ESDCS
      GOTO_END_ESDCS 17
    }

  # Back level version uninstall failed
    function BCKLVL_VER_UNINSTALL_FAILED_ESDCS
    {
      echo . >> $swdPkgLog
      echo "ERROR: Back level version uninstallation FAILED." >> $swdPkgLog
      echo "Upgrade installation FAILED: error code 18." >> $swdPkgLog

      CLEANUP_ESDCS
      GOTO_END_ESDCS 18
    }

  # No Current Version Check
    function NO_CUR_VER_CHK_ESDCS
    {
      echo . >> $swdPkgLog
      echo "ERROR: No current version check is available." >> $swdPkgLog
      echo "Current version check aborted: error code 21." >> $swdPkgLog

      CLEANUP_ESDCS
      GOTO_END_ESDCS 21
    }

  # No Verification Check
    function NO_VERIFY_CHK_ESDCS
    {
      echo . >> $swdPkgLog
      echo "ERROR: No installation verification check is available." >> $swdPkgLog
      echo "Verification check aborted: error code 22." >> $swdPkgLog

      CLEANUP_ESDCS
      GOTO_END_ESDCS 22
    }

  # Newer version installed
    function NEWER_VER_INSTALLED_ESDCS
    {
      echo . >> $swdPkgLog
      echo "ERROR: Newer verion is installed." >> $swdPkgLog
      echo "Installation FAILED: error code 23." >> $swdPkgLog

      CLEANUP_ESDCS
      GOTO_END_ESDCS 23
    }

  # Back level version installed
    function BCK_LVL_VER_INSTALLED_ESDCS
    {
      echo . >> $swdPkgLog
      echo "ERROR: Back level version installed." >> $swdPkgLog
      echo "Installation FAILED: error code 24." >> $swdPkgLog

      CLEANUP_ESDCS
      GOTO_END_ESDCS 24
    }

  # Process or service not running
    function PROCESS_OR_SRVC_NT_RUNNING_ESDCS
    {
      echo . >> $swdPkgLog
      echo "ERROR: Process or Service NOT running." >> $swdPkgLog
      echo "Installation FAILED: error code 25." >> $swdPkgLog

      CLEANUP_ESDCS
      GOTO_END_ESDCS 25
    }

  # Agent not conected
    function AGENT_NT_CONNECTED_ESDCS
    {
      echo . >> $swdPkgLog
      echo "ERROR: Agent NOT connected." >> $swdPkgLog
      echo "Installation FAILED: error code 26." >> $swdPkgLog

      CLEANUP_ESDCS
      GOTO_END_ESDCS 26
    }

  # Initial scan failed
    function INITIAL_SCN_FAILED_ESDCS
    {
      echo . >> $swdPkgLog
      echo "ERROR: Initial scan FAILED." >> $swdPkgLog
      echo "Installation FAILED: error code 27." >> $swdPkgLog

      CLEANUP_ESDCS
      GOTO_END_ESDCS 27
    }

  # Error Admin Script failure
   function ADMIN_SCRIPT_FAILED_ESDCS
   {
      echo . >> $swdPkgLog
      echo "ERROR: Administrative script failed." >> $swdPkgLog
      echo "Installation FAILED: error code 30." >> $swdPkgLog

      CLEANUP_ESDCS
      GOTO_END_ESDCS 30
   }
# ********** END FUNCTION DEFINITIONS *****************************


# ********** SET ENVIRONMENT VARIABLES ****************************
  swdEnvFile=$1

  swdWorkDir=$2
  swdDistDir=$3
  imgDir=$4
  rspDir=$5
  pkgDir=$6
  instType=$7
  swdRebootAfter=$8
  swdUninstall=$9

  # Had to use if statement because for loop will not work on blank var
  if [[ "$swdWorkDir" = "" ]] || [[ "$swdDistDir" = "" ]] || [[ "$imgDir" = "" ]] ||
     [[ "$rspDir" = "" ]] || [[ "$pkgDir" = "" ]] || [[ "$instType" = "" ]] || [[ "$swdRebootAfter" = "" ]] ||
     [[ "$swdUninstall" = "" ]]
  then
     echo "Missing parameter value!" 1>&2
     exit 29
  fi

  shift
  until [ -z "$9" ]
  do
  eval ${9%^^^*}=${9#*^^^}
    shift
  done
  if [[ -n ${swdEnvFile} ]]
  then
    . $swdEnvFile
    rc=$?

    if [[ "$rc" != 0 ]]
    then
       GOTO_END 5
    fi
  fi

  swdUninstall="$(echo "$swdUninstall" |tr 'a-z' 'A-Z')"
  swdIncludeImg="$(echo "$swdIncludeImg" |tr 'a-z' 'A-Z')"
  swdRebootAfter="$(echo "$swdRebootAfter" |tr 'a-z' 'A-Z')"
  swdCleanup="$(echo "$swdCleanup" |tr 'a-z' 'A-Z')"
  swdSpcChk="$(echo "$swdSpcChk" |tr 'a-z' 'A-Z')"
  swdOSVerChk="$(echo "$swdOSVerChk" |tr 'a-z' 'A-Z')"
  swdVerifyChk="$(echo "$swdVerifyChk" |tr 'a-z' 'A-Z')"
  swdCurVerChk="$(echo "$swdCurVerChk" |tr 'a-z' 'A-Z')"
  swdDistOnly="$(echo "$swdDistOnly" |tr 'a-z' 'A-Z')"

  # Initializing other variables
    swdNormalInst=N
    swdSpcChkLog=${swdWorkDir}/${swdProduct}_swdSpcChk.log
    whichLog=$swdPkgLog

  # Checking to see if this is a validation or a normal installation
  if [[ "$swdSpcChk" = "ALL" ]] && [[ "$swdOSVerChk" = "ALL" ]] && [[ "$swdVerifyChk" = "ALL" ]] && [[ "$swdCurVerChk" = "ALL" ]]
  then
     swdNormalInst=Y
  fi

# ********** END SET ENVIRONMENT VARIABLES ************************


# if $swdWorkDir does not exist, create it
  if ! [[ -d $swdWorkDir ]]
  then
     mkdir -p -m 775 "$swdWorkDir"
  fi

# Start logging
  echo --------------------------------------------------------- > $swdPkgLog

  echo "Date/Time COMMIT script started:" >> $swdPkgLog
  date >> $swdPkgLog

  echo Input parms are ... >> $swdPkgLog
  echo swdWorkDir is $swdWorkDir >> $swdPkgLog
  echo swdDistDir is $swdDistDir >> $swdPkgLog
  echo imgDir is $imgDir >> $swdPkgLog
  echo rspDir is $rspDir >> $swdPkgLog
  echo pkgDir is $pkgDir >> $swdPkgLog
  echo instType is $instType >> $swdPkgLog
  echo swdRebootAfter is $swdRebootAfter >> $swdPkgLog
  echo swdUninstall is $swdUninstall >> $swdPkgLog
  echo esdStdVer is $esdStdVer >> $swdPkgLog
  echo swdSpcChk is $swdSpcChk >> $swdPkgLog
  echo swdOSVerChk is $swdOSVerChk >> $swdPkgLog
  echo swdVerifyChk is $swdVerifyChk >> $swdPkgLog
  echo swdCurVerChk is $swdCurVerChk >> $swdPkgLog
  echo . >> $swdPkgLog

  echo ^^^DESCRIPTION: $swdPkgDesc^^^ >> $swdPkgLog

# ********** BEGIN INSTALL SPACE CHECK ****************************
if [[ "$swdSpcChk" = "Y" ]] || [[ "$swdSpcChk" = "YES" ]]
then
   whichLog=$swdSpcChkLog
else
   whichLog=$swdPkgLog
fi

if [[ -n $swdIFS ]]
then
  echo .  >> $whichLog
  echo "Checking for proper $swdIFS filesystem..." >> $whichLog

  if [[ -d $swdIFS ]]
  then
    echo "$swdIFS directory exists." >> $whichLog

    echo .  >> $whichLog
    echo "Checking if $swdIFS is a filesystem..." >> $whichLog
    grep " $swdIFS " /etc/fstab >/dev/null 2>&1
    rc=$?

    if [[ "$rc" = 0 ]]
    then
      echo "$swdIFS is a fileystem." >> $whichLog

      echo .  >> $whichLog
      echo "Ensuring the $swdIFS filesystem is mounted..." >> $whichLog
      MOUNT_FS_ESDCS ${swdIFS}
      rc=$?

      if [[ "$rc" != 0 ]]
      then
        if [[ "$swdNormalInst" != "Y" ]]
        then
          CLEANUP_ESDCS
          echo "^^^ERROR: Could not mount $swdIFS filesystem.^^^" >> $swdPkgLog
          GOTO_END_ESDCS 9
        else
          echo "^^^ERROR: Could not mount $swdIFS filesystem.^^^" >> $swdPkgLog
          GOTO_END_ESDCS 9
        fi
      fi

    else
      echo "$swdIFS is NOT a fileystem." >> $whichLog
    fi
  else
    echo "$swdIFS was not found; creating it..."
    mkdir -p -m 755 "$swdIFS" >/dev/null 2>&1
    rc=$?

    if [[ "$rc" != 0 ]]
    then
      echo "^^^ERROR: $swdIFS was not found; could not create $swdIFS.^^^" >> $swdPkgLog
      NO_INST_SPACE_ESDCS
    fi
  fi


  echo .  >> $whichLog
  echo "Checking $swdIFS for installation space..." >> $whichLog
  FREE=`df $swdIFS | tail -1 | awk '{print $2, $3, $4}' | awk '{print $3}'`
  SIZE=`df $swdIFS | tail -1 | awk '{print $2, $3, $4}' | awk '{print $1}'`

  echo "$SIZE 1024-byte blocks size." >> $whichLog
  echo "$FREE 1024-byte blocks free." >> $whichLog
  echo "$swdISpace 1024-byte blocks needed." >> $whichLog

  if [[ $FREE -lt $swdISpace ]]
  then
    echo "^^^ERROR: $swdIFS does NOT have enough free space ($FREE 1024-byte blocks).  $swdISpace 1024-byte blocks are needed.^^^" >> $swdPkgLog
    echo "ERROR: $swdIFS does NOT have enough free space ($FREE 1024-byte blocks)." >> $whichLog
    NO_INST_SPACE_ESDCS
  else
    echo "$swdIFS has enough free space ($FREE 1024-byte blocks)." >> $whichLog
  fi
else
  echo "$swdIFS is not set..." >> $whichLog
  echo "Install space checking will not be performed in the commit script..." >> $whichLog
fi


  whichLog=$swdPkgLog

# ********** END INSTALL SPACE CHECK ******************************


# ********** CHECK DISTRIBUTE ONLY ********************************
  if [[ -f $swdWorkDir/BUILDSHEET ]]
  then
    DistOnly=`cat "$swdWorkDir/BUILDSHEET" | grep DistOnly= | cut -f2- -d=`
    DistOnly="$(echo "$DistOnly" |tr 'a-z' 'A-Z')"
    if [[ "$DistOnly" = "YES" ]] || [[ "$DistOnly" = "Y" ]]
    then

      distOnlyInstall=${swdWorkDir}/${swdProduct}_manual_install.ksh
      echo \#!/bin/sh > $distOnlyInstall
      echo "# *********************************************************************** #" >> $distOnlyInstall
      echo "# Licensed Materials - Property of IBM" >> $distOnlyInstall
      echo "#" >> $distOnlyInstall
      echo "# � Copyright IBM Corp. 2000, 2010     All Rights Reserved" >> $distOnlyInstall
      echo "# *********************************************************************** #" >> $distOnlyInstall
      echo swdPkgLog=$swdPkgLog>> $distOnlyInstall
      echo swdInstall=$swdInstall>> $distOnlyInstall
      echo swdProduct=$swdProduct>> $distOnlyInstall
      echo swdPkgDesc=\"$swdPkgDesc\">> $distOnlyInstall
      echo swdPkgLvl=$swdPkgLvl>> $distOnlyInstall
      echo swdLang=$swdLang>> $distOnlyInstall
      echo swdCust=$swdCust>> $distOnlyInstall
      echo swdOS=$swdOS>> $distOnlyInstall
      echo swdISpace=$swdISpace>> $distOnlyInstall
      echo swdWorkDir=$swdWorkDir>> $distOnlyInstall
      echo swdDistDir=$swdDistDir>> $distOnlyInstall
      echo imgDir=$imgDir>> $distOnlyInstall
      echo rspDir=$rspDir>> $distOnlyInstall
      echo pkgDir=$pkgDir>> $distOnlyInstall
      echo swdRebootAfter=$swdRebootAfter>> $distOnlyInstall
      echo swdUninstall=$swdUninstall>> $distOnlyInstall
      echo esdStdVer=$esdStdVer >> $distOnlyInstall
      echo swdSpcChk=$swdSpcChk >> $distOnlyInstall
      echo swdOSVerChk=$swdOSVerChk >> $distOnlyInstall
      echo swdVerifyChk=$swdVerifyChk >> $distOnlyInstall
      echo swdCurVerChk=$swdCurVerChk >> $distOnlyInstall
      echo echo . \> $swdPkgLog >> $distOnlyInstall
      echo echo "Invoking installation script: $swdInstall" >> $distOnlyInstall
      echo . $pkgDir/$swdInstall >> $distOnlyInstall
      echo rc=\$? >> $distOnlyInstall
      echo echo RC=\$rc >> $distOnlyInstall

      chmod 777 $distOnlyInstall

      echo .  >> $swdPkgLog
      echo "DistOnly is set to yes; leaving files in $swdDistDir and skipping install." >> $swdPkgLog
      GOTO_END_ESDCS 0
    fi

  fi
# ********** END CHECK DISTRIBUTE ONLY ****************************


# ********** BEGIN INSTALL SCRIPT *********************************
  echo .  >> $swdPkgLog
  echo "Invoking installation script: $swdInstall" >> $swdPkgLog
  . $pkgDir/$swdInstall
  rc=$?

  if [[ "$rc" = 1 ]]
  then
    NO_DIST_SPACE_ESDCS
  elif [[ "$rc" = 2 ]]
  then
    NO_INST_SPACE_ESDCS
  elif [[ "$rc" = 3 ]]
  then
    ALREADY_INSTALLED_ESDCS
  elif [[ "$rc" = 6 ]]
  then
    PRE_INSTALL_FAILED_ESDCS
  elif [[ "$rc" = 7 ]]
  then
    POST_INSTALL_FAILED_ESDCS
  elif [[ "$rc" = 8 ]]
  then
    PREREQ_FAILED_ESDCS
  elif [[ "$rc" = 12 ]]
  then
    SKIP_INSTALL_ESDCS
  elif [[ "$rc" = 17 ]]
  then
    UNSUPPORTED_BCK_LVL_VER_ESDCS
  elif [[ "$rc" = 18 ]]
  then
    BCKLVL_VER_UNINSTALL_FAILED_ESDCS
  elif [[ "$rc" = 21 ]]
  then
    NO_CUR_VER_CHK_ESDCS
  elif [[ "$rc" = 22 ]]
  then
    NO_VERIFY_CHK_ESDCS
  elif [[ "$rc" = 23 ]]
  then
    NEWER_VER_INSTALLED_ESDCS
  elif [[ "$rc" = 24 ]]
  then
    BCK_LVL_VER_INSTALLED_ESDCS
  elif [[ "$rc" = 25 ]]
  then
    PROCESS_OR_SRVC_NT_RUNNING_ESDCS
  elif [[ "$rc" = 26 ]]
  then
    AGENT_NT_CONNECTED_ESDCS
  elif [[ "$rc" = 27 ]]
  then
    INITIAL_SCN_FAILED_ESDCS
  elif [[ "$rc" = 30 ]]
  then
    ADMIN_SCRIPT_FAILED_ESDCS
  elif [[ "$rc" != 0 ]]
  then
    INSTALL_FAILED_ESDCS
  fi
# ********** END INSTALL SCRIPT ***********************************


# ********** BEGIN SOURCE IMAGE CLEANUP ***************************
  if [[ "$swdCleanup" = "YES" ]]  || [[ "$swdCleanup" = "Y" ]]
  then
    CLEANUP_ESDCS
  else
    echo .  >> $swdPkgLog
    echo "swdCleanup is set to no; leaving files in $swdDistDir/$swdProduct." >> $swdPkgLog
  fi
# ********** END SOURCE IMAGE CLEANUP *****************************


# ********** BEGIN REBOOT CHECK ***********************************
  if [[ "$swdRebootAfter" = "YES" ]] || [[ "$swdRebootAfter" = "Y" ]]
  then
    echo .  >> $swdPkgLog
    echo "System reboot is being initiated..." >> $swdPkgLog
    shutdown -r +1 &

    if [ $? != 0 ]
    then
      echo "ERROR: shutdown command failed with rc=$?." >> $swdPkgLog

      echo .  >> $swdPkgLog
      echo "Trying reboot command instead of shutdown..." >> $swdPkgLog
      reboot &

      if [ $? != 0 ]
      then
        echo "^^^ERROR: Reboot command failed with rc=$?.^^^" >> $swdPkgLog
        GOTO_END_ESDCS 20
      fi
    fi

  fi
# ********** END REBOOT CHECK *************************************


GOTO_END_ESDCS 0
