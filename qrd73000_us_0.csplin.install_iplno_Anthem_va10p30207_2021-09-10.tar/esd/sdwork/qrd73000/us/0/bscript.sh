#!/bin/sh
# ************************************************************************* #
# Licensed Materials - Property of IBM
#
# � Copyright IBM Corp. 2000, 2010     All Rights Reserved
# ************************************************************************* #


# ************************************************************************* #
# BEFORE SCRIPT FOR LINUX
# ************************************************************************* #
# ESD Standard Version 12
# ************************************************************************* #
# Modifications
# 02/27/2006 - Initial Release - Changed Architecture
# 05/08/2007 - Updated to allow for more that 10 input params 10+
#              Will come in as key^^^value pairs.
# 07/30/2007 - Added code for SD-TSA requirements giving new functionality
#              to allow for space checking without installing using utils pkg
# 09/27/2007 - Added code for asset tracking to create the sig file and pkg
#              asset tag file.
# 11/12/2009 - Modified df command.
# 12/07/2009 - Additional changes to df command to handle long LV names
# 09/08/2010 - Added COMPUTERNAME/HOSTNAME echo at the end of the logging.
# 10/21/2010 - Added new code to support swdCurVer function.
# ************************************************************************* #


# ************************************************************************* #
# Return Codes:
#   0:  SUCCESS
#   1:  NOT ENOUGH DIST SPACE
#   2:  NOT ENOUGH INST SPACE
#   3:  ALREADY INSTALLED
#   5:  INSTALL SCRIPT FAILURE
#   6:  PRE-INSTALLATION CONFIGURATION FAILURE
#   7:  POST-INSTALLATION CONFIGURATION FAILURE
#   8:  PRE-REQUISITE NOT PRESENT
#   9:  UNABLE TO CREATE/MOUNT FILESYSTEM
#  11:  UNABLE TO INSTALL/DISTRIBUTE FILES
#  20:  SHUTDOWN FAILED
# ************************************************************************* #


# ********** VARIABLE DECLARATIONS ********************************
  # initialize return code
    bsrc=0

  # set path
    PATH=$PATH:/usr/sbin:/usr/local/sbin
# ********** END VARIABLE DECLARATIONS ****************************


# ********** FUNCTION DEFINITIONS *********************************
  # End Program Function
    function GOTO_END
    {
      bsrc=$1

      echo . >> $swdPkgLog
      echo "Date/Time BEFORE script completed on `hostname`:" >> $swdPkgLog
      date >> $swdPkgLog
      echo --------------------------------------------------------- >> $swdPkgLog
      exit $bsrc
    }


  # Cleanup $swdDistDir Filesystem
    function CLEANUP
    {
      echo . >> $swdPkgLog
      echo "Cleaning up the $swdDistDir/$swdProduct directory..." >> $swdPkgLog
      rm -r $swdDistDir/$swdProduct

      if [[ -d $swdDistDir/lost+found ]]
      then
        echo "Cleaning up the $swdDistDir/lost+found directory..." >> $swdPkgLog
        rm -r $swdDistDir/lost+found/*
      fi

      remains=`ls $swdDistDir`

      if [[ -z $remains ]]
      then
        echo "The $swdDistDir directory is empty." >> $swdPkgLog
        echo "Unmounting $swdDistDir filesystem..." >> $swdPkgLog
        umount $swdDistDir

        #echo "Cleaning up the $swdDistDir directory..." >> $swdPkgLog
        #rm -r $swdDistDir
      else
        echo "The $swdDistDir directory still contains files." >> $swdPkgLog
      fi
    }


  # Mount A Filesystem
    function MOUNT_FS
    {
      fs=$1

      temp=`mount | grep " $fs "`

      if [[ -z $temp ]]
      then
        mount $fs >/dev/null 2>&1
        rc=$?

        if [[ "$rc" != 0 ]]
        then
          echo "ERROR: mounting $fs filesystem." >> $swdPkgLog
          return 1
        else
          echo "$fs filesystem mounted properly." >> $swdPkgLog
        fi
      else
        echo "$fs filesystem is already mounted." >> $swdPkgLog
      fi

      return 0
    }


  # Not Enough DASD to Distribute
    function NO_DIST_SPACE
    {
      echo . >> $swdPkgLog
      echo "^^^DESCRIPTION: $swdPkgDesc^^^" >> $swdPkgLog
      echo "^^^ERROR: Insufficient DASD to distribute, need at least $swdDSpace 1024-byte blocks.^^^" >> $swdPkgLog
      echo "Distribute aborted: error code 1." >> $swdPkgLog

      CLEANUP
      GOTO_END 1
    }


  # Not Enough DASD to Install
    function NO_INST_SPACE
    {
      echo . >> $swdPkgLog
      echo "ERROR: Insufficient DASD to install, need at least $swdISpace 1024-byte blocks." >> $swdPkgLog
      echo "Distribute aborted: error code 2." >> $swdPkgLog

      CLEANUP
      GOTO_END 2
    }


  # Package is Already Installed
    function ALREADY_INSTALLED
    {
      echo . >> $swdPkgLog
      echo "ERROR: $swdPkgDesc is already installed." >> $swdPkgLog
      echo "Distribute aborted: error code 3." >> $swdPkgLog

      CLEANUP
      GOTO_END 3
    }


  # Installation Command Failed
    function INSTALL_FAILED
    {
      echo . >> $swdPkgLog
      echo "ERROR: $swdInstall script returned non-zero." >> $swdPkgLog
      echo "Distribute aborted: error code 5." >> $swdPkgLog

      GOTO_END 5
    }


  # Pre-Installation Failed
    function PRE_INSTALL_FAILED
    {
      echo . >> $swdPkgLog
      echo "ERROR: Pre-installation configuration failed." >> $swdPkgLog
      echo "Distribute aborted: error code 6." >> $swdPkgLog

      CLEANUP
      GOTO_END 6
    }


  # Post-Installation Failed
    function POST_INSTALL_FAILED
    {
      echo . >> $swdPkgLog
      echo "ERROR: Post-installation configuration failed." >> $swdPkgLog
      echo "Distribute aborted: error code 7." >> $swdPkgLog

      CLEANUP
      GOTO_END 7
    }


  # Pre-requisite File Not Found
    function PREREQ_FAILED
    {
      swdPre=$1

      echo . >> $swdPkgLog
      echo "ERROR: $swdPre is NOT installed." >> $swdPkgLog
      echo "Distribute aborted: error code 8." >> $swdPkgLog

      CLEANUP
      GOTO_END 8
    }
# ********** END FUNCTION DEFINITIONS *****************************


# ********** SET ENVIRONMENT VARIABLES ****************************
  swdEnvFile=$1

  swdWorkDir=$2
  swdDistDir=$3
  imgDir=$4
  rspDir=$5
  pkgDir=$6
  instType=$7
  swdIncludeImg=$8

  # Had to use if statement because for loop will not work on blank var
  if [[ "$swdWorkDir" = "" ]] || [[ "$swdDistDir" = "" ]] || [[ "$imgDir" = "" ]] ||
     [[ "$rspDir" = "" ]] || [[ "$pkgDir" = "" ]] || [[ "$instType" = "" ]] ||
     [[ "$swdIncludeImg" = "" ]]
  then
     echo "Missing parameter value!" 1>&2
     exit 29
  fi

  shift
  until [ -z "$8" ]
  do
  eval ${8%^^^*}=${8#*^^^}
    shift
  done
  if [[ -n ${swdEnvFile} ]]
  then
    . $swdEnvFile
    rc=$?

    if [[ "$rc" != 0 ]]
    then
       GOTO_END 5
    fi
  fi

  swdSpcChk=`echo $swdSpcChk|tr "[a-z]" "[A-Z]"`
  swdOSVerChk=`echo $swdOSVerChk|tr "[a-z]" "[A-Z]"`
  swdVerifyChk=`echo $swdVerifyChk|tr "[a-z]" "[A-Z]"`

  # Initializing other variables
    assetsDir=/var/.SWDist_Sig
    assetTagFile=${assetsDir}/OSPESDAssetTag
    esdSigFileName="esd.${swdProduct}_${swdLang}_${swdPkgLvl}-${swdCust}${swdOS}.exe"
    swdNormalInst=N
    swdSpcChkLog=${swdWorkDir}/${swdProduct}_swdSpcChk.log
    whichLog=$swdPkgLog

  # Asset Tracking
   mkdir -p -m 755 ${assetsDir}
   echo DESCRIPTION\=\"ESD Signature File for Asset Tracking\">${assetsDir}/$esdSigFileName
   echo echo \$DESCRIPTION>>${assetsDir}/$esdSigFileName
   chmod 775 ${assetsDir}/$esdSigFileName

   asset_date=`date +%D`
   asset_time=`date +%T`
   asset_target=`hostname`

   echo ${swdProduct}_${swdLang}_${swdPkgLvl}.${swdCust}${swdOS}.${instType}_${iplType}.spb^^^$asset_target^^^$asset_date^^^$asset_time>> $assetTagFile

  # Checking to see if this is a validation or a normal installation
  if [[ "$swdSpcChk" = "ALL" ]] && [[ "$swdOSVerChk" = "ALL" ]] && [[ "$swdVerifyChk" = "ALL" ]]
  then
     swdNormalInst=Y
  fi

# ********** END SET ENVIRONMENT VARIABLES ************************


# if $swdWorkDir does not exist, create it
  if ! [[ -d $swdWorkDir ]]
  then
     mkdir -p -m 775 "$swdWorkDir"
  fi

# Start logging
  echo --------------------------------------------------------- > $swdPkgLog
  echo "Date/Time BEFORE script started:" >> $swdPkgLog
  date >> $swdPkgLog

  echo Input parms are ... >> $swdPkgLog
  echo swdWorkDir is $swdWorkDir >> $swdPkgLog
  echo swdDistDir is $swdDistDir >> $swdPkgLog
  echo imgDir is $imgDir >> $swdPkgLog
  echo rspDir is $rspDir >> $swdPkgLog
  echo pkgDir is $pkgDir >> $swdPkgLog
  echo instType is $instType >> $swdPkgLog
  echo swdIncludeImg is $swdIncludeImg >> $swdPkgLog
  echo esdStdVer is $esdStdVer >> $swdPkgLog
  echo swdSpcChk is $swdSpcChk >> $swdPkgLog
  echo swdOSVerChk is $swdOSVerChk >> $swdPkgLog
  echo swdVerifyChk is $swdVerifyChk >> $swdPkgLog
  echo . >> $swdPkgLog

# ********** BEGIN FILESYSTEM CHECK/CREATE ************************
  if [[ "$swdSpcChk" = "Y" ]] || [[ "$swdSpcChk" = "YES" ]]
  then
     whichLog=$swdSpcChkLog
     echo "Checking for Distribution Space (Before Script)" > $whichLog
     echo .  >> $whichLog
  else
     whichLog=$swdPkgLog
  fi

  echo "Checking for proper $swdDistDir filesystem..." >> $whichLog

  if [[ -d $swdDistDir ]]
  then
    echo "$swdDistDir directory exists." >> $whichLog
  else
    echo "$swdDistDir was not found; creating it..." >> $whichLog
    mkdir -p -m 755 $swdDistDir >/dev/null 2>&1
    rc=$?

    if [[ "$rc" != 0 ]]
    then
      NO_DIST_SPACE
    fi
  fi

  echo .  >> $whichLog
  echo "Checking if $swdDistDir is a filesystem..." >> $whichLog
  grep " $swdDistDir " /etc/fstab >/dev/null 2>&1
  rc=$?

  if [[ "$rc" = 0 ]]
  then
    echo "$swdDistDir is a fileystem." >> $whichLog
    echo .  >> $whichLog
    echo "Ensuring the $swdDistDir filesystem is mounted..." >> $whichLog
    MOUNT_FS ${swdDistDir}
    rc=$?

    if [[ "$rc" != 0 ]]
    then
      GOTO_END 9
    fi
  else
    grep $swdDistDir /etc/fstab >/dev/null 2>&1
    rc=$?

    if [[ "$rc" = 0 ]]
    then
      echo "$swdDistDir is a fileystem." >> $whichLog
      echo .  >> $whichLog
      echo "Ensuring the $swdDistDir filesystem is mounted..." >> $whichLog
      MOUNT_FS ${swdDistDir}
      rc=$?

      if [[ "$rc" != 0 ]]
      then
        GOTO_END 9
      fi
    else
      echo "$swdDistDir is NOT a fileystem." >> $whichLog
    fi
  fi

  echo .  >> $whichLog
  echo "Checking $swdDistDir for distribution space..." >> $whichLog
  lvNameLine=`df / | tail -1 | grep -v '^/'`
  if [[ $lvNameLine = "" ]]; then
     FREE=`df $swdDistDir | tail -1 | awk '{print $2, $3, $4}' | awk '{print $3}'`
     SIZE=`df $swdDistDir | tail -1 | awk '{print $2, $3, $4}' | awk '{print $1}'`
  else
     FREE=`df $swdDistDir | tail -1 | awk '{print $1, $2, $3}' | awk '{print $3}'`
     SIZE=`df $swdDistDir | tail -1 | awk '{print $1, $2, $3}' | awk '{print $1}'`
  fi

  echo "$SIZE 1024-byte blocks size." >> $whichLog
  echo "$FREE 1024-byte blocks free." >> $whichLog
  echo "$swdDSpace 1024-byte blocks needed." >> $whichLog

  if [[ $FREE -lt $swdDSpace ]]
  then
    echo "$swdDistDir does NOT have enough free space ($FREE)." >> $whichLog
    NO_DIST_SPACE
  else
    echo "$swdDistDir has enough free space ($FREE)." >> $whichLog
  fi

  whichLog=$swdPkgLog
# ********** END FILESYSTEM CHECK/CREATE **************************


# ********** CLEANUP BUILDSHEET **********************************
  if [[ -f $swdWorkDir/BUILDSHEET ]]
  then
    echo .  >> $swdPkgLog
    echo "BUILDSHEET already exists; it will be deleted..." >> $swdPkgLog
    rm -r $swdWorkDir/BUILDSHEET >/dev/null 2>&1
  fi
# ********** END CLEANUP BUILDSHEET ******************************


GOTO_END 0

