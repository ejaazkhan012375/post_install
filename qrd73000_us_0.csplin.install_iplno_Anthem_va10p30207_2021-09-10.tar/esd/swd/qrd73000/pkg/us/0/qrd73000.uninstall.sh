#!/bin/bash

################################################################################
# Licensed Materials - Property of IBM
#
#
# � Copyright IBM Corp. 2006-2018          All Rights Reserved
################################################################################
# *-----------------------------------------------------------------------------
# * ESD Standard Version 14 (14.0.17010300)
# *-----------------------------------------------------------------------------
# * Modifications: 08/28/2017 hvazquez - Initial release
# *-----------------------------------------------------------------------------
# * Template Modifications:
# *    MHR - 01/03/2017 - New revision, minor typo error and changes updates
# *-----------------------------------------------------------------------------
# *
# *   *** ATTENTION ***
# *
# *   **ERRORS**
# *
# *   We need to provide as many details on why a package may have failed.
# *   We need this ERROR message to be in a specific format.
# *
# *   For example, if the current ESD message is:
# *
# *   echo "Installation of $swdProduct FAILED; $appFile or configuration file samgr.conf_${configFile} FAILED..." >> $swdPkgLog
# *
# *   You would need modify the line by adding ^^^ERROR: at the beginning and ^^^ at the end of the message.
# *
# *   echo "^^^ERROR: Installation of $swdProduct FAILED; $appFile or configuration file samgr.conf_${configFile} FAILED.^^^" >> $swdPkgLog
# *
# *   NOTE:  You can have multiple ^^^ lines in the log if you have more than one prereq check failure.  Please test for prereq check failures during testing!
# *
# *   --------------------------------------------------------------------------
# *
# *   **WARNINGS**
# *
# *   A package requirement may also require a WARNING message to be created for a specific situation.
# *   If such a request is made in the requirement, a WARNING message should be in a specific format.
# *
# *   A WARNING message should have ^W^WARNING: at the beginning and ^W^ at the end of the message.
# *
# *   For example:
# *
# *   echo "^W^WARNING: The runonce group has not been created!^W^" >> $swdPkgLog
# *
# *   NOTE:  The W is a capital letter.
# *          You can have multiple ^W^ lines in the log if you have more than one WARNING.
# *          Create WARNING messages ONLY if there is a specific requirement for a WARNING message.
# *
# *-----------------------------------------------------------------------------
# *----------------- Sample ERROR MESSAGES you may adjust and use. -------------
# echo "^^^ERROR: Unsupported OS version <os> found.^^^" >> $swdPkgLog
# echo "^^^ERROR: Required command <command> Not found.^^^"  >> $swdPkgLog
# echo "^^^ERROR: Installation failed while running the command: <command> <command parameters>.^^^" >> $swdPkgLog
# echo "^^^ERROR: Configuration failed, aborting installation.^^^" >> $swdPkgLog
# echo "^^^ERROR: Failed to start <agent or service or process>. CMD: <command>.^^^" >> $swdPkgLog
# *-----------------------------------------------------------------------------

###################################################################
#*#*#*#*#*#* ESD PACKAGE INITIALIZATION
###################################################################
# ********** ECHO ESD STANDARD VARIABLES **************************
  #***************#
  # Do Not Change
  #***************#
    echo swdProduct is $swdProduct >> $swdPkgLog
    echo swdPkgDesc is $swdPkgDesc >> $swdPkgLog
    echo swdPkgLvl is $swdPkgLvl >> $swdPkgLog
    echo swdLang is $swdLang >> $swdPkgLog
    echo swdCust is $swdCust >> $swdPkgLog
    echo swdOS is $swdOS >> $swdPkgLog
    echo swdPkgLog is $swdPkgLog >> $swdPkgLog
    echo swdWorkDir is $swdWorkDir >> $swdPkgLog
    echo swdDistDir is $swdDistDir >> $swdPkgLog
    echo imgDir is $imgDir >> $swdPkgLog
    echo rspDir is $rspDir >> $swdPkgLog
    echo pkgDir is $pkgDir >> $swdPkgLog
    echo instType is $instType >> $swdPkgLog
    echo esdStdVer is $esdStdVer >> $swdPkgLog
    echo swdRebootAfter is $swdRebootAfter >> $swdPkgLog
    echo swdUninstall is $swdUninstall >> $swdPkgLog
    echo swdSpcChk is $swdSpcChk >> $swdPkgLog
    echo swdOSVerChk is $swdOSVerChk >> $swdPkgLog
    echo swdVerifyChk is $swdVerifyChk >> $swdPkgLog
    echo swdCurVerChk is $swdCurVerChk >> $swdPkgLog

# ********** SET BUILDSHEET VARIABLE ******************************
    custBUILDSHEET=/esd/custom/${swdProduct}_${swdLang}_${swdPkgLvl}_BUILDSHEET
    if [[ -f $custBUILDSHEET ]]
    then
      BUILDSHEET=$custBUILDSHEET
    else
      BUILDSHEET=${swdWorkDir}/BUILDSHEET
    fi

# ********** SET MISCELLANEOUS VARIABLES **************************
    tmpOut=${swdWorkDir}/temp.out
    rspFile=${rspDir}/setup.response
    swdNormalInst=N
    swdSpcChkLog=${swdWorkDir}/${swdProduct}_swdSpcChk.log
    whichLog=$swdPkgLog
    linArch=all
    rc=0
    fctnRC=0
    prereqNotMet=false
    sigfile=qrd73000_us_0-csplin.txt
# ********** ECHO HEADER INFORMATION TO LOG ***********************
  echo "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-" >> $swdPkgLog
  if [[ "$swdSpcChk" = "ALL" ]] && [[ "$swdOSVerChk" = "ALL" ]] && [[ "$swdVerifyChk" = "ALL" ]] && [[ "$swdCurVerChk" = "ALL" ]]
  then
    echo "Beginning normal installation of $swdPkgDesc..." >> $swdPkgLog
    swdNormalInst=Y
  else
    echo "Beginning validation of $swdPkgDesc..." >> $swdPkgLog
  fi

  echo BUILDSHEET is $BUILDSHEET >> $swdPkgLog
  date >> $swdPkgLog
###################################################################
#*#*#*#*#*#* END ESD PACKAGE INITIALIZATION
###################################################################

# ********** RETURN CODE INFORMATION ******************************
  # NON-SUCCESS
    function ERR {
      echo . >> $swdPkgLog
      echo "Package Operation for $swdPkgDesc FAILED." >> $swdPkgLog
      echo "Returning to commit script with \$rc = 5..." >> $swdPkgLog
      echo "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-" >> $swdPkgLog
      return 5
    }

  # NON-SUCCESS
    function PREREQ_NOT_MET {
      prereqNotMet=true
      echo . >> $swdPkgLog
      echo "A pre-requisite was NOT met." >> $swdPkgLog
    }

  # NON-SUCCESS
    function OS_PREREQ_NOT_MET {
      prereqNotMet=true
      echo . >> $swdPkgLog
      echo "A pre-requisite was NOT met." >> $swdPkgLog
      echo "Returning to commit script with \$rc = 8..." >> $swdPkgLog
      echo "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-" >> $swdPkgLog
      return 8
    }

  # NON-SUCCESS
    function UNSUPPORTED_BCK_LVL_VER {
      echo . >> $swdPkgLog
      echo "Unsupported back level version was found." >> $swdPkgLog
      echo "Returning to commit script with \$rc = 17..." >> $swdPkgLog
      echo "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-" >> $swdPkgLog
      return 17
    }

  # NON-SUCCESS
    function BCK_LVL_VER_UNINSTALL_FAILED {
      echo . >> $swdPkgLog
      echo "Back level version uninstallation FAILED." >> $swdPkgLog
      echo "Returning to commit script with \$rc = 18..." >> $swdPkgLog
      echo "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-" >> $swdPkgLog
      return 18
    }

  # NON-SUCCESS
    function NO_INSTALL_VERIFICATION_CHK_AVAILABLE {
      echo . >> $swdPkgLog
      echo "^^^ERROR: No installation verification check is available.^^^" >> $swdPkgLog
      echo "Returning to commit script with \$rc = 22..." >> $swdPkgLog
      echo "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-" >> $swdPkgLog
      return 22
    }

  # NON-SUCCESS
    function NEWER_VER_INSTALLED {
      echo . >> $swdPkgLog
      echo "Newer version is installed." >> $swdPkgLog
      echo "Returning to commit script with \$rc = 23..." >> $swdPkgLog
      echo "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-" >> $swdPkgLog
      return 23
    }

  # NON-SUCCESS
    function BCK_LVL_VER_INSTALLED {
      echo . >> $swdPkgLog
      echo "Back level version is installed." >> $swdPkgLog
      echo "Returning to commit script with \$rc = 24..." >> $swdPkgLog
      echo "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-" >> $swdPkgLog
      return 24
    }

  # SUCCESS
    #SKIP_INSTALL HAS RC=0 BUT CAN BE SET TO 12 UPON CUSTOMER REQUEST
    function SKIP_UNINSTALL {
      echo . >> $swdPkgLog
      echo "^^^SKIP UNINSTALL^^^" >> $swdPkgLog
      echo "Un-installation of $swdPkgDesc is NOT needed." >> $swdPkgLog
      echo "Returning to commit script with \$rc = 0..." >> $swdPkgLog
      #echo "Returning to commit script with \$rc = 12..." >> $swdPkgLog
      echo "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-" >> $swdPkgLog
      #return 12
      return 0
    }

  # SUCCESS
    function OK {
      echo . >> $swdPkgLog
      echo "^^^SUCCESS^^^" >> $swdPkgLog
      echo "Package Operation for $swdPkgDesc completed SUCCESSFULLY." >> $swdPkgLog
      echo "Returning to commit script with \$rc = 0..." >> $swdPkgLog
      echo "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-" >> $swdPkgLog
      return 0
    }

  # MOSTLY FOR SECURITY ADVISORIES
    function REMOVE_SIG_FILE {
      sig_file=$sigfile

      echo . >> $swdPkgLog
      echo "Removing signature file..." >> $swdPkgLog
      if [[ -f /var/.SWDist_Sig/${sig_file} ]]
      then
        rm -r /var/.SWDist_Sig/${sig_file}
        return $?  #The return code of this function will not be zero if the sig file was found but not removed
      else
        echo "$sig_file not found."
        return 0   #The return code will be zero if the file is not found
      fi
    }
# ********** END RETURN CODE INFORMATION **************************

# ********** PACKAGE SPECIFIC FUNCTIONS ***************************
# ********** END PACKAGE SPECIFIC FUNCTIONS ***********************

###################################################################
#*#*#* O/S VERSION CHECK *#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#
###################################################################
if [[ "$swdNormalInst" = "Y" ]] || [[ "$swdOSVerChk" = "Y" ]] || [[ "$swdOSVerChk" = "YES" ]]
then
# ********** O/S VERSION CHECK ************************************
  preReqVar=`cat /etc/redhat-release | awk -F'(' '{print $1}' | awk '{print $NF}'`

  echo . >> $swdPkgLog
  echo "Beginning OS version check for Red Hat Enterprise Linux..." >> $swdPkgLog

  if [ `echo $preReqVar | grep -c 2.1` = 1 ]
  then
    os=2.1
    echo "...Red Hat Enterprise Linux $os was found." >> $swdPkgLog
    echo "^^^ERROR: This package is not supported fot RedHat Linux $os.^^^" >> $swdPkgLog
    prereqNotMet=true
    OS_PREREQ_NOT_MET
    fctnRC=$?
    if [[ $fctnRC -ne 0 ]]
    then
       return $fctnRC
    fi

  elif [[ `echo $preReqVar | grep -c ^3` = 1 ]]
  then
    os=3.0
    echo "...Red Hat Enterprise Linux $preReqVar was found." >> $swdPkgLog
    echo "^^^ERROR: This package is not supported fot RedHat Linux $os.^^^" >> $swdPkgLog
    prereqNotMet=true
    OS_PREREQ_NOT_MET
    fctnRC=$?
    if [[ $fctnRC -ne 0 ]]
    then
       return $fctnRC
    fi
  elif [[ `echo $preReqVar | grep -c ^4` = 1 ]]
  then
    os=4.0
    echo "...Red Hat Enterprise Linux $preReqVar was found." >> $swdPkgLog
    echo "^^^ERROR: This package is not supported fot RedHat Linux $os.^^^" >> $swdPkgLog
    prereqNotMet=true
    OS_PREREQ_NOT_MET
    fctnRC=$?
    if [[ $fctnRC -ne 0 ]]
    then
       return $fctnRC
    fi
  elif [[ `echo $preReqVar | grep -c ^5` = 1 ]]
  then
    os=5.0
    echo "...Red Hat Enterprise Linux $preReqVar was found." >> $swdPkgLog
  elif [ `echo $preReqVar | grep -c ^6` = 1 ]
  then
    os=6.0
    echo "...Red Hat Enterprise Linux $preReqVar was found." >> $swdPkgLog
  elif [ `echo $preReqVar | grep -c ^7` = 1 ]
  then
    os=7.0
    echo "...Red Hat Enterprise Linux $preReqVar was found." >> $swdPkgLog
  else
    echo "^^^ERROR: Could not determine version of Red Hat; aborting the install.^^^" >> $swdPkgLog
    OS_PREREQ_NOT_MET
    fctnRC=$?
    if [[ $fctnRC -ne 0 ]]
    then
      return $fctnRC
    fi
  fi
# ********** END O/S VERSION CHECK ********************************

## ********** HARDWARE PLATFORM CHECK *****************************
## ********** END HARDWARE PLATFORM CHECK *************************

# ********** O/S ARCH CHECK ***************************************
  OS_ARCH=`uname -m | grep x86_64`;
  if [[ "$linArch" = "all" ]]
  then
     echo "32-bit and 64-bit architectures are supported..." >>$swdPkgLog
  else
     if [[ "$OS_ARCH" != "" ]] && [[ "$linArch" = "64-bit" ]]
     then
        echo "...Found 64-bit architecture..." >>$swdPkgLog
        echo "...Expecting 64-bit architecture..." >>$swdPkgLog
     elif [[ "$OS_ARCH" != "" ]] && [[ "$linArch" = "32-bit" ]]
     then
        echo "^^^ERROR: Found 64-bit RHEL architecture, expecting 32-bit RHEL architecture; aborting the install.^^^" >>$swdPkgLog
        OS_PREREQ_NOT_MET
        fctnRC=$?
        if [[ $fctnRC -ne 0 ]]
        then
           return $fctnRC
        fi
     elif [[ "$OS_ARCH" = "" ]] && [[ "$linArch" = "32-bit" ]]
     then
        echo "...Found 32-bit architecture..." >>$swdPkgLog
        echo "...Expecting 32-bit architecture..." >>$swdPkgLog
     elif [[ "$OS_ARCH" = "" ]] && [[ "$linArch" = "64-bit" ]]
     then
        echo "^^^ERROR: Found 32-bit RHEL architecture, expecting 64-bit RHEL architecture; aborting the install.^^^" >>$swdPkgLog
        OS_PREREQ_NOT_MET
        fctnRC=$?
        if [[ $fctnRC -ne 0 ]]
        then
           return $fctnRC
        fi
     fi
  fi
# ********** END O/S ARCH CHECK ***********************************
fi
###################################################################
#*#*#* END O/S VERSION CHECK *#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#
###################################################################

# ********** LIST / SET BUILDSHEET DEFAULT VARIABLE VALUES ********
# ********** END LIST / SET BUILDSHEET DEFAULT VARIABLE VALUES ****

###################################################################
#*#*#* EXIT IF PREREQ_NOT_MET *#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*
if [[ "$prereqNotMet" = "true" ]]
then
  echo "Returning to commit script with \$rc = 8..." >> $swdPkgLog
  echo "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-" >> $swdPkgLog
  return 8
fi
###################################################################

###################################################################
#*#*#* UNINSTALL SECTION *#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#
###################################################################
if [[ "$swdNormalInst" = "Y" ]]
then
# ********** SKIP UNINSTALL SECTION *******************************
# Check to see if the product is installed, if it is not installed,
# Make a call to SKIP_UNINSTALL.  Default is RC=0, unless there is a
# specific requirement fo RC=12.

    ## Check to see if product is installed here.##
	echo "Beginning verification installation check..." >> $swdPkgLog
  	echo . >> $swdPkgLog
	echo "." >> $swdPkgLog
	echo "Checking if /var/.SWDist_Sig/$sigfile exist..." >> $swdPkgLog
	if [[ ! -f /var/.SWDist_Sig/$sigfile ]]
	then
		echo "$swdPkgDesc was NOT found installed on the system." >> $swdPkgLog
		SKIP_UNINSTALL
		fctnRC=$?
		if [[ $fctnRC -eq 0 ]]
		then
			return $fctnRC
		fi
	else
		echo "/var/.SWDist_Sig/$sigfile file was found. Package $swdPkgDesc is installed, continuing uninstall..." >> $swdPkgLog
	fi
    
## Message to log. ##
    # echo "$swdPkgDesc was not found installed on the system." >> $swdPkgLog

    # SKIP_UNINSTALL
    # fctnRC=$?
    # if [[ $fctnRC -ne 0 ]]
    # then
    #   return $fctnRC
    # fi

# ********** UNINSTALLATION SECTION *******************************
  # Un-install Application

### Change in version V7.3

echo ".">> $swdPkgLog
echo "Setting audit path. " >> $swdPkgLog

if [[ $os = "7.0" ]]
then
path_audit=/etc/audit/rules.d
else
path_audit=/etc/audit
fi

echo "audit path set to $path_audit." >> $swdPkgLog

### Change in version V7.3 END 


	echo . >> $swdPkgLog
    echo "Un-installing $swdPkgDesc..." >> $swdPkgLog
  IFS=" "
  bkpfiles="audit.rules rc.local"
	
	for bkpfile in $bkpfiles
	do
    if [[ $bkpfile = "audit.rules" ]]
		then
			pathfile="/etc/audit"
		elif [[ $bkpfile = "rc.local" ]]
		then
			pathfile="/etc/rc.d"
		fi

	if [[ -f $pathfile/backout.qradar/$bkpfile ]]
	then
		echo "Restoring $pathfile/backout.qradar/$bkpfile to $pathfile/$bkpfile" >> $swdPkgLog 2>&1
		cp -fp $pathfile/backout.qradar/$bkpfile $pathfile/$bkpfile >> $swdPkgLog 2>&1
		fctnRC=$?
		if [[ $fctnRC -ne 0 ]]
		then
			echo "^^^ERROR: an error has ocurred restoring backup from $pathfile/backout.qradar/$bkpfile to $pathfile/$bkpfile^^^"  >> $swdPkgLog
			ERR
			fctnRC=$?
			if [[ $fctnRC -ne 0 ]]
			then
				return $fctnRC
			fi
		else
			echo "Backup restored from $pathfile/backout.qradar/$bkpfile to $pathfile/$bkpfile" >> $swdPkgLog
			echo "Atempting to remove $pathfile/backout.qradar directory"  >> $swdPkgLog
			rm -fr $pathfile/backout.qradar >> $swdPkgLog 2>&1
			fctnRC=$?
			if [[ $fctnRC -ne 0 ]]
			then
				echo "the backup directory $pathfile/backout.qradar could not be deleted, please remove it manually."  >> $swdPkgLog
        echo "." >> $swdPkgLog
			else
				echo "$pathfile/backout.qradar directory removed successfully" >> $swdPkgLog
        echo "." >> $swdPkgLog
			fi
		fi
	fi
	done

  echo . >> $swdPkgLog
  echo "Restarting auditd service." >> $swdPkgLog
  service auditd restart >> $swdPkgLog 2>&1
  fctnRC=$?
  if [[ $fctnRC -ne 0 ]]
  then
    echo "^^^ERROR: an error has ocurred restarting the auditd service.^^^"  >> $swdPkgLog
    ERR
    fctnRC=$?
    if [[ $fctnRC -ne 0 ]]
    then
      return $fctnRC
    fi
  else
    echo "Service auditd restarted successfully" >> $swdPkgLog
  fi 
  
	if [[ -d /opt/tail2syslog ]]
	then
		echo "Deleting /opt/tail2syslog folder"  >> $swdPkgLog
		rm -fr /opt/tail2syslog >> $swdPkgLog 2>&1
		fctnRC=$?
		if [[ $fctnRC -ne 0 ]]
		then
			echo "^^^ERROR: An error has ocurred deleting /opt/tail2syslog folder.^^^"  >> $swdPkgLog
			ERR
			fctnRC=$?
			if [[ $fctnRC -ne 0 ]]
			then
				return $fctnRC
			fi
		else
			echo "/opt/tail2syslog folder Deleted"  >> $swdPkgLog
		fi
	fi

	REMOVE_SIG_FILE
	fctnRC=$?
	if [[ $fctnRC -ne 0 ]]
	then
		return $fctnRC
	fi
	# ********** END UNINSTALLATION SECTION ***************************
fi
###################################################################
#*#*#* END UNINSTALL SECTION *#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#
###################################################################

###################################################################
#*#*#* VERIFY INSTALL CHECK ## REQUIRED FOR ALL PACKAGES *#*#*#*#*#
###################################################################
if [[ "$swdVerifyChk" = "Y" ]] || [[ "$swdVerifyChk" = "YES" ]]
then
  echo . >> $swdPkgLog
  echo "Beginning verification installation check..." >> $swdPkgLog
  #This is the normal installation verification.  All successful installation verification should take place in the
  #INSTAL SECTION instead of in this section.  This section should be coded to check and see whether or not the application is installed on the system.
  #You can use the same concept as your code in the already installed section, but do not perform a check for an esd created signature file
  #because a customer could already have this application installed by some other means than the ESD package.

  echo . >> $swdPkgLog
  #If there is no normal installation verification AND there is no customer specific installation verification listed in the requirements,
  #make sure to uncomment "#NO_INSTALL_VERIFICATION_CHK_AVAILABLE" and related fctnRC check.
  #NO_INSTALL_VERIFICATION_CHK_AVAILABLE
  #fctnRC=$?
  #if [[ $fctnRC -ne 0 ]]
  #then
  #  return $fctnRC
  #fi

  ##Verify install check goes here.##
	echo "Checking if /var/.SWDist_Sig/$sigfile exist..." >> $swdPkgLog
	if [[ ! -f /var/.SWDist_Sig/$sigfile ]]
	then
		echo "/var/.SWDist_Sig/$sigfile file not found" >> $swdPkgLog
		echo "$swdPkgDesc Uninstalled Sucessfully. Verification Success" >> $swdPkgLog
	else
		echo "^^^ERROR: /var/.SWDist_Sig/$sigfile file found, $swdPkgDesc was found installed on the system.^^^" >> $swdPkgLog
		ERR
		fctnRC=$?
		if [[ $fctnRC -ne 0 ]]
		then
			return $fctnRC
		fi
	fi
  #If there is a verification check and the application is found installed on the system, please use this error message and related fctnRC check.
  #echo "^^^ERROR: $swdPkgDesc was found installed on the system.^^^" >> $swdPkgLog
  #  ERR
  #  fctnRC=$?
  #  if [[ $fctnRC -ne 0 ]]
  #  then
  #    return $fctnRC
  #  fi
fi
###################################################################
#*#*#* END VERIFY INSTALL CHECK *#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*
###################################################################
OK
