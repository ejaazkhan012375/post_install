#!/bin/bash

# AUTHOR: Jorge Quintana
# Version: 2.7
# Last Update: 01/29/2014

# History of updates:
# Version 1.0: Initial draft, test successful in all supported OSs (HP-UX, AIX, Solaris, Linux)
# Version 1.1: Fixed bug report by Mariano Sternheim - 
#                     Bug in function "whichFileSystem"
#                     Changed testing approach and added failsafes for the different operating systems
#                     there were cases in the original function which could have caused the function to 
#                     report wrongfully
# Version 2.0: Added functionality for checking ammount of Unallocated Space on AIX systems
# Version 2.1: Fixed bug report by Sergio Martin
#                     Bug in functions "listFileSystems" "isEnoughAvail"
#                     Slightly changed "df" command output formats to avoid joined fields in Solaris
#                     and output splitted in two lines on Linux
#                     in both cases this happened when the device and/or its mount points are large
#                     strings
#Version 2.3: Fixed the issue by Kultenko Vadym
#                     It was found, if on target server there are duplcated mounted FS,
#                     the script crashes with syntax error. In order to avoid this issue,
#                     after the list of the mounted fs has being created, all duplcated entries are deleted.
#Version 2.4: Added functionality to sum up repeated directories in the SpcReq file by Emmanuel Pedros
#                     Whenever there is a repeated directory name on the SpcReq file
#                     the script would fail. To prevent this the function Verify_SpcReq
#                     was created. The function itself processes the SpcReq file summing
#                     up the split space requirements for a filesystem. Please reffer to
#                     the function definition for more information.
#Version 2.5: Added functionality to list only local filesystems on AIX OS by Freddy Chaparro
#
#
#Version 2.6: Added functionality to verify if a dir to check is repeated by Freddy Chaparro
#                     If one or more directory is repated, the script sum the two or more values 
#                     as one only value for the directry.
#Version 2.7: Fixed bug issue report by Hernan Muro
#                     If one or more directorys name passed as a empty value, the script have two issues, 
#                     First, if the directory to check is empty, this script run successfuly and exit returning RC=0. 
#                     Now, with this fix, the script check if the Directory Name is empty and exit with an ERROR message. 
#                     Second, under certain circuntances the command `grep -c $Dir_name $file` return 0  when checking 
#                     the Directory name with a empty value, to avoid this special case, now the script exit with an 
#                     ERROR message. (Return 0, is a Not expected value, because the Directory Name to check don't matched 
#                     with another Directory Name in the list provided to validate. Valid values expected for this 
#                     grep are 1 or more)


# If These functions are going to be part of a package script the following section can be omitted
# it is only to ensure that a needed variable is defined and if not it defines it to default the same as the 
# package script if possible, if not, every temp file will be written to the root dir if possible (and if not
# the whole script will fail)
# It also defines the log for this script if it is not already defined

Version=2.7
Debug="Y"

if [[ -z "$swdWorkDir" ]]
then
  if [[ -d "/esd/sdwork" && -w "/esd/sdwork" ]]
  then
    swdWorkDir="/esd/sdwork" 
  else
    swdWorkDir=""
  fi
fi

if [[ -z "$swdPkgLog" ]]
then
  swdPkgLog="${swdWorkDir}/functions.log"
fi

# Function to go up one directory on the directory structure until root dir (/)
# The return string is stored in variable $oneUp
# The directory to perform the operation upon must be passed in as a parameter

function goUpOne {
  
  oneUp=`echo ${1%\/*}` # This uses Sub-strings 
  if [[ -z $oneUp ]]
  then
    oneUp='/'
  fi
}

# Function to generate a list of currently mounted filesystems as they appear as output of the df command
# This list is stored to a file with the following format
# <fs1>:0000
# <fs2>:0000
# ...
# <fsn>:0000

# The 0000 is a symbollic value to represent that 0 bytes are to be queried in each file
# This is for compatibility with another function that will edit this file to include in that last token
# the ammount of space to query in each filesystem
# The name of the target filep must be passed in as the only parameter

function listFileSystems {
  
  lin="Linux"
  hpu="HP-UX"
  sun="SunOS"
  aix="AIX"

  listFs="$1"
  tmpFile="${swdWorkDir}/tmp.tmp"
  rm -f $listFs >>/dev/null 2>&1
  rm -f $tmpFile >>/dev/null 2>&1
  
  osType=`uname`
  
  case $osType in
    $lin)
        field=6
        dfCmd="df -Pl" #Portable Posix Format, local fss only
        ;;
    $hpu)
      field=6
      dfCmd="df -Pkl" #Portable Posix Format, local fss only, show usage in KB
      ;;
    $sun)
      field=6
      dfCmd="df -kl" #local fss only, show usage in KB
      ;;
    $aix)
      field=6
      dfCmd="df -Pk" #Portable Posix Format, show usage in KB
      ;;
  esac
  
  if [[ "$osType" = "$aix" ]]
  then
    cat /etc/filesystems | grep ":" | grep -v ^* | grep -v ^# | grep -v ^, | awk -F\: '{print $1}' >> $listFs
  else
    $dfCmd | grep -v "Mounted on$" |awk "{print \$$field}" >> $listFs
  fi
  
# $dfCmd | grep -v "Mounted" |awk "{print \$$field}" >> $listFs #ALL OSs tested
  sed 's#\(.*\)#\1:0000#' $listFs >> $tmpFile #HPU, SUN, AIX tested
  mv -f $tmpFile $listFs
  rm -f $tmpFile >>/dev/null 2>&1
}

# This function needs a directory passed in as parameter and returns the filesystem that directory
# belongs to, on the variable $currentDirTest

function whichFilesystem {
  
  lin="Linux"
  hpu="HP-UX"
  sun="SunOS"
  aix="AIX"
  
  osType=`uname`
  
  case $osType in
    $hpu)
       dfCmd="df -P"
       ;;
    $sun)
       dfCmd="df -k"
       ;;
    *)
       dfCmd="df"
       ;;
  esac
  
  
  currentDirTest=$1
  fsCount=`$dfCmd | grep -c ${currentDirTest}$`
  
  while [[ $fsCount -eq 0  ]]
  do
    goUpOne $currentDirTest # Function Call
    currentDirTest=$oneUp
    fsCount=`$dfCmd | grep -c ${currentDirTest}$`
  done
  
}

# This function takes in as parameters the SpaceChecks file and The listFs file to update the latter 
# with the values from the first
# Format for SpaceChecks file:
# dir1:SpaceToQuery1
# dir2:SpaceToQuery2
# dir3:...
# i.e. If both dir1 and dir2 are members of FS1 the new listFs file will look like the following
# FS1:(SpaceToQuery1 + SpaceToQuery2)
# FS2:0000
# FS3:...
function updateListFsFile {
  sourceFile=$1
  targetFile=$2
  tmpFileDir="${swdWorkDir}/tmpDirs.tmp"
  tmpFile="${swdWorkDir}/tmp.tmp"
  
  rm -f $tmpFileDir >>/dev/null 2>&1
  rm -f $tmpFile >>/dev/null 2>&1
  cat $sourceFile | cut -d: -f1 >> $tmpFileDir

  
  for directory in `cat $tmpFileDir`
  do
    whichFilesystem $directory # Function Call
    # The filesystem is returned in $currentDirTest
    (( newSpace = `grep "^$currentDirTest:" $targetFile | cut -d: -f2-` + `grep "^$directory:" $sourceFile | cut -d: -f2-` ))
    # Sum tested on HPUX LINUX and SOLARIS
    # Linux Tested
    if [[ "$osType" != "$sun" ]]
    then
      sed "s#\(^$currentDirTest:\).*#\1$newSpace#" $targetFile >> $tmpFile 
      #The above sed does not work on Solaris (at least on Solaris 8 - The save buffers do not work)
    else
      sed "s#^$currentDirTest:.*#$currentDirTest:$newSpace#" $targetFile >> $tmpFile
    fi
    mv -f $tmpFile $targetFile >>/dev/null 2>&1
  done
  
  rm -f $tmpFile >>/dev/null 2>&1
  rm -f $tmpFileDir >>/dev/null 2>&1
}

# Pass this function as an argument the name of the file where the spaces to be checked for each directory are stored
# This function will call all the others as they are needed
# If any of the queried filesystems does not have enough space 1 is returned, if all the checks are successful 0 is returned


function isEnoughAvail {
  fsList="${swdWorkDir}/fsList.txt"
  spaceCheckings=$1
  flag=0
  sort_command=""
  
  lin="Linux"
  hpu="HP-UX"
  sun="SunOS"
  aix="AIX"
  
  osType=`uname`
  
  case $ostype in
    $lin)
        sort_command="/bin/sort"
        ;;
    *)        #aix and solaris, hp
        sort_command="/usr/bin/sort"
        ;;
  esac
  
  listFileSystems $fsList # Function Call
  
  if [[ "$Debug" = "Y" ]]
  then 
  # Debugging
    echo . >> $swdPkgLog
    echo "############## Original list of filesystems ############" >> $swdPkgLog
    echo $fsList >> $swdPkgLog
    echo . >> $swdPkgLog
    cat $fsList >> $swdPkgLog
    echo . >> $swdPkgLog
    echo "############## Original input file #####################" >> $swdPkgLog
    echo $spaceCheckings >> $swdPkgLog
    echo . >> $swdPkgLog
    cat $spaceCheckings >> $swdPkgLog
    echo . >> $swdPkgLog
  # End Debugging 
  fi
  
  updateListFsFile $spaceCheckings $fsList # Function Call
  #Eliminating duplicate entries
  if [[ -f "$sort_command" ]]
  then
    tmpFile="${swdWorkDir}/tmp.tmp"
    rm -f $tmpFile
    $sort_command -u $fsList > $tmpFile
    if [[ $? -eq 0 ]]
    then
      mv $tmpFile $fsList 
    fi
  fi
  
  if [[ "$Debug" = "Y" ]]
  then 
  # 
    echo . >> $swdPkgLog
    echo "############# Updated list of filesystems ##############" >> $swdPkgLog
    echo $fsList >> $swdPkgLog
    echo . >> $swdPkgLog
    cat $fsList >> $swdPkgLog
    echo . >> $swdPkgLog
  # End Debugging
  fi
  
  for Fs in `cat $fsList | cut -d: -f1`
  do 
    case $osType in
      $hpu)
         free=$( df -k $Fs | grep "free" | awk '{print $1}' )
         ;;
      $aix)
         free=$( df -k $Fs | grep -v "Mounted on$" | awk '{print $3}' )
         ;;
      $lin)
         free=$( df -Pk $Fs | grep -v "Mounted on$" | awk '{print $4}' )
         ;;
      $sun)
         free=$( df -k $Fs | grep -v "Mounted on$" | awk '{print $4}' )
         ;;
    esac  
    needed=`grep "^$Fs:" $fsList | cut -d: -f2-`
    if [[ $needed -ne 0 ]]
    then
      echo "Filesystem: $Fs" >> $swdPkgLog
      if [[ $free -ge $needed ]]
      then 
        echo "Enough space available on $Fs" >> $swdPkgLog
        
      else 
        flag=1
        echo "There is NOT enough space available on $Fs" >> $swdPkgLog
      fi
      echo "total space available on $Fs $free KB..." >> $swdPkgLog
      echo "   ... and a total of $needed free KB are required on $Fs" >> $swdPkgLog
      echo . >> $swdPkgLog
    fi
  done
  
  rm -f $fsList >>/dev/null 2>&1
return $flag
}

function Verify_SpcReq {
  echo "Checking $1 ..." >> $swdPkgLog
  #Parameter verification
  if [[ -z $1 ]] || [[ $1 = "" ]]
  then
    echo "ERROR: The filename cannot be empty." >> $swdPkgLog
    return 255
  fi
  
  if [[ ! -f $1 ]]
  then
    echo "ERROR: The file $1 doesn't exist." >> $swdPkgLog
    return 254
  fi
  
  #Initialization
  file=$1
  repeat_index=0
  
  if [[ -f $file.new ]]
  then
    echo "$file.new exists... attempting to remove it" >> $swdPkgLog
    rm -fr $file.new
    rc=$?
    if [[ $rc -ne 0 ]]
    then
      echo "ERROR: Could not remove $file.new" >> $swdPkgLog
      return 253
    fi
  fi
  
  if [[ -f $file.orig ]]
  then
    echo "$file.orig exists... attempting to remove it" >> $swdPkgLog
    rm -fr $file.orig
    rc=$?
    if [[ $rc -ne 0 ]]
    then
      echo "ERROR: Could not remove $file.orig" >> $swdPkgLog
      return 252
    fi
  fi
  
  #Reading the file
  while read line 
  do
    repeated=0
    i=0
    Dir_name=`echo $line | cut -d':' -f1`

    if [[ -z $Dir_name ]]
    then
      echo "$line" >> $file.new
      echo "ERROR: could not check an empty directory name" >> $swdPkgLog
      return 249
    fi

      if [[ `grep -c $Dir_name $file` -eq 0 ]]
      then
        echo "$line" >> $file.new
        echo "ERROR: Directory name don't mismatch with any directory in the list." >> $swdPkgLog
        return 248
      fi

    if [[ `grep -c $Dir_name $file` -eq 1 ]]
    then
      echo "$line" >> $file.new
    else
      if [[ $repeat_index -ne 0 ]]
      then
        while [[ $i -le $repeat_index ]]
        do
          if [[ "$Dir_name" = "${repetition_list[$i]}" ]]
          then
            repeated=1
            i=`expr 1 + $repeat_index`
          fi
          i=`expr $i + 1`
        done
      fi
      
      if [[ $repeated -eq 0 ]]
      then
        sum_var=0
        while read value
        do
          curr_dirname=`echo $value | cut -d':' -f1`
          if [[ "$curr_dirname" = "$Dir_name" ]]
          then
            curr_val=`echo $value | cut -d':' -f2`
            sum_var=`expr $sum_var + $curr_val`
          fi
        done<$file
        echo "$Dir_name:$sum_var" >> $file.new
        repeat_index=`expr $repeat_index + 1`
        repetition_list[${repeat_index}]=$Dir_name
      fi
      
      
    fi
    
  done<$file
  
  echo "Moving $file to $file.orig" >> $swdPkgLog
  mv $file $file.orig
  rc=$?
  if [[ $rc -ne 0 ]]
  then
    echo "ERROR: could not move $file to $file.orig" >> $swdPkgLog
    return 251
  fi
  
  echo "Moving $file.new to $file" >> $swdPkgLog
  mv $file.new $file
  rc=$?
  if [[ $rc -ne 0 ]]
  then
    echo "ERROR: could not move $file.new to $file" >> $swdPkgLog
    return 250
  fi  
  return 0
}

# This function verifies that there are no repeated directory names. In case there are any the ammount of space is summed up 
# and a new SpcReq file is created. A filename must be provided to the function as a parameter.

# Example:

# /bin:300
# /var/srm:200
# /bin:200
# /bin/sys:600

# Will be processed and the result will be:

# /bin:500
# /var/srm:200
# /bin/sys:600

# The function also creates a SpcReq.orig file even if no modifications are done to the SpcReq itself. 
# Any return code other than 0 means the function failed in some way


# END FUNCTION DEFINITIONS SECTION #

function usage {
  echo "USAGE: $1 <inputFile> [<unallocated_space_to_query>]"
  echo "       $1 -V prints out version and exit"
  echo .
  echo "This program checks for free space in the filesystems that match the directories" 
  echo "listed in <inputFile> The syntax of <inputFile> is: "
  echo "<dir1>:<space_to_query>"
  echo "<dir2>:<space_to_query>"
  echo "..."
  echo "<dirN>:<space_to_query>"
  echo "where <space_to_query> is a whole number representing the ammount of KBs free"
  echo "needed on each for each directory"
  echo "Contact the developer for a sample <inputFile>"
  echo .
  echo "Optional parameter <unallocated_space_to_query> works only on AIX and is a "
  echo "whole number representing the ammount of free MBs not currently allocated needed"
  echo .
}

#################################################################################################
# MAIN #
if [[ $# -lt 1 ]]
then
  usage $0
  return -1
fi

inputFile=$1
if [[ $# -eq 2 ]]
then
  queryUnalloc=$2
fi

if [[ $inputFile = "-V" ]]
then
  echo "$0 Version: $Version"
  echo "Developer: Jorge Quintana"
  echo "Release date: 10/05/2009"
  echo "Last updated by: Hernan Muro"
  echo "Modification date: 01/29/2014"
  echo .
  return 0
fi

if [[ ! -f $inputFile ]]
then
  echo "$inputFile not a regular file..."
  echo .
  usage $0
  return -2
fi

# Verifying if any directory is repeated

for dir in `sort $inputFile | cut -d: -f1 | uniq -d`
do
  inputFile_tmp="${swdWorkDir}/inputFile_tmp"
  echo "dir $dir is repeated.. processing like only one dir, summing the two sizes in one"
  new_dir_size=`grep $dir $inputFile | cut -d: -f2 | awk '{ s += $1 } END { print s }'`
  new_dir_value=$dir:$new_dir_size
  cat $inputFile | grep -v $dir >> $inputFile_tmp
  echo "$new_dir_value" >> $inputFile_tmp
  mv $inputFile_tmp $inputFile
done
#------------------------------------------------ 


Verify_SpcReq $inputFile # Function Call
if [[ $? -ne 0 ]]
then
  echo "ERROR, take a look at the $swdPkgLog file to determine the cause"
  return 1
fi

isEnoughAvail $inputFile # Function Call
if [[ $? -ne 0 ]]
then
  echo "ERROR, take a look at the $swdPkgLog file to determine the cause"
  return 1
fi

if [[ -n $queryUnalloc ]]
then
  if [[ `uname` = "AIX" ]]
  then
    freeUnalloc=`lsvg rootvg | grep "FREE" | cut -d'(' -f2 | awk '{print $(NF -1)}'`
    if [[ -n $freeUnalloc ]]
    then
      echo "Unallocated space: $freeUnalloc MB ... " >> $swdPkgLog
      echo "Needed unallocated space: $queryUnalloc MB ..." >> $swdPkgLog
      if [[ $freeUnalloc -ge $queryUnalloc ]]
      then
        echo "Enough Unallocated space available..." >> $swdPkgLog
      else
        echo "There is NOT enough Unallocated space available..." >> $swdPkgLog
        return 1
      fi
    else
      echo "Could not determine ammount of Unallocated space, Aborting..." >> $swdPkgLog
      return 2
    fi
  else
    echo "`uname` support for this feature is not implemented yet..."
    usage $0
    return -1
  fi
fi
    

return 0
##################################################################################################


