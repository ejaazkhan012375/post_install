#!/bin/bash
        case $# in
                0)
                        echo verifyIPFormat: error: one operand is required.
                        echo verifyIPFormat: aborting IP format verification.
                        return 255
                        ;;
                1)
                        ;;

                *)
                        echo verifyIPFormat: error: more than one operand specified.
                        echo verifyIPFormat: aborting IP format verification.
                        return 254
                        ;;
        esac

regex="^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?$)"
echo $1 | egrep $regex > /dev/null 2>&1
retVal=$?
if [[ $retVal -ne 0 ]]
then
        echo The value provided is not a valid IP Address. The value provided is: $1
else
        echo The value provided is a valid IP Address: $1
fi

return $retVal
