#!/bin/bash

################################################################################
# Licensed Materials - Property of IBM
#
#
# � Copyright IBM Corp. 2006-2018          All Rights Reserved
################################################################################
# *-----------------------------------------------------------------------------
# * ESD Standard Version 14 (14.0.17010300)
# *-----------------------------------------------------------------------------
# * Modifications: 08/28/2017 hvazquez - Initial release
# *-----------------------------------------------------------------------------
# * Template Modifications:
# *    MHR - 01/03/2017 - New revision, minor typo error and changes updates
# *-----------------------------------------------------------------------------
# *
# *   *** ATTENTION ***
# *
# *   **ERRORS**
# *
# *   We need to provide as many details on why a package may have failed.
# *   We need this ERROR message to be in a specific format.
# *
# *   For example, if the current ESD message is:
# *
# *   echo "Installation of $swdProduct FAILED; $appFile or configuration file samgr.conf_${configFile} FAILED..." >> $swdPkgLog
# *
# *   You would need modify the line by adding ^^^ERROR: at the beginning and ^^^ at the end of the message.
# *
# *   echo "^^^ERROR: Installation of $swdProduct FAILED; $appFile or configuration file samgr.conf_${configFile} FAILED.^^^" >> $swdPkgLog
# *
# *   NOTE:  You can have multiple ^^^ lines in the log if you have more than one prereq check failure.  Please test for prereq check failures during testing!
# *
# *   --------------------------------------------------------------------------
# *
# *   **WARNINGS**
# *
# *   A package requirement may also require a WARNING message to be created for a specific situation.
# *   If such a request is made in the requirement, a WARNING message should be in a specific format.
# *
# *   A WARNING message should have ^W^WARNING: at the beginning and ^W^ at the end of the message.
# *
# *   For example:
# *
# *   echo "^W^WARNING: The runonce group has not been created!^W^" >> $swdPkgLog
# *
# *   NOTE:  The W is a capital letter.
# *          You can have multiple ^W^ lines in the log if you have more than one WARNING.
# *          Create WARNING messages ONLY if there is a specific requirement for a WARNING message.
# *
# *-----------------------------------------------------------------------------
# *----------------- Sample ERROR MESSAGES you may adjust and use. -------------
# echo "^^^ERROR: Unsupported OS version <os> found.^^^" >> $swdPkgLog
# echo "^^^ERROR: Required command <command> Not found.^^^"  >> $swdPkgLog
# echo "^^^ERROR: Installation failed while running the command: <command> <command parameters>.^^^" >> $swdPkgLog
# echo "^^^ERROR: Configuration failed, aborting installation.^^^" >> $swdPkgLog
# echo "^^^ERROR: Failed to start <agent or service or process>. CMD: <command>.^^^" >> $swdPkgLog
# *-----------------------------------------------------------------------------

###################################################################
#*#*#*#*#*#* ESD PACKAGE INITIALIZATION
###################################################################
# ********** ECHO ESD STANDARD VARIABLES **************************
  #***************#
  # Do Not Change
  #***************#
    echo swdProduct is $swdProduct >> $swdPkgLog
    echo swdPkgDesc is $swdPkgDesc >> $swdPkgLog
    echo swdPkgLvl is $swdPkgLvl >> $swdPkgLog
    echo swdLang is $swdLang >> $swdPkgLog
    echo swdCust is $swdCust >> $swdPkgLog
    echo swdOS is $swdOS >> $swdPkgLog
    echo swdPkgLog is $swdPkgLog >> $swdPkgLog
    echo swdWorkDir is $swdWorkDir >> $swdPkgLog
    echo swdDistDir is $swdDistDir >> $swdPkgLog
    echo imgDir is $imgDir >> $swdPkgLog
    echo rspDir is $rspDir >> $swdPkgLog
    echo pkgDir is $pkgDir >> $swdPkgLog
    echo instType is $instType >> $swdPkgLog
    echo esdStdVer is $esdStdVer >> $swdPkgLog
    echo swdRebootAfter is $swdRebootAfter >> $swdPkgLog
    echo swdUninstall is $swdUninstall >> $swdPkgLog
    echo swdSpcChk is $swdSpcChk >> $swdPkgLog
    echo swdOSVerChk is $swdOSVerChk >> $swdPkgLog
    echo swdVerifyChk is $swdVerifyChk >> $swdPkgLog
    echo swdCurVerChk is $swdCurVerChk >> $swdPkgLog

# ********** SET BUILDSHEET VARIABLE ******************************
    custBUILDSHEET=/esd/custom/${swdProduct}_${swdLang}_${swdPkgLvl}_BUILDSHEET
    if [[ -f $custBUILDSHEET ]]
    then
      BUILDSHEET=$custBUILDSHEET
    else
      BUILDSHEET=${swdWorkDir}/BUILDSHEET
    fi

# ********** SET MISCELLANEOUS VARIABLES **************************
    tmpOut=${swdWorkDir}/temp.out
    rspFile=${rspDir}/setup.response
    swdNormalInst=N
    swdSpcChkLog=${swdWorkDir}/${swdProduct}_swdSpcChk.log
    whichLog=$swdPkgLog
    linArch=all
    rc=0
    admrc=0
    fctnRC=0
    prereqNotMet=false
    noInstSpace=false
    sigfile=qrd73000_us_0-csplin.txt
    
    tempFile=${swdWorkDir}"/TemporalFile"
    tempFile2=${swdWorkDir}"/TemporalFile2"  

# ********** SET ADMIN SCRIPT DEFINITIONS *************************
    swdAdmBefore=/esd/adm/admin_shutdown.sh
    swdAdmAfter=/esd/adm/admin_startup.sh

# ********** ECHO HEADER INFORMATION TO LOG ***********************
  echo "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-" >> $swdPkgLog
  if [[ "$swdSpcChk" = "ALL" ]] && [[ "$swdOSVerChk" = "ALL" ]] && [[ "$swdVerifyChk" = "ALL" ]] && [[ "$swdCurVerChk" = "ALL" ]]
  then
    echo "Beginning normal installation of $swdPkgDesc..." >> $swdPkgLog
    swdNormalInst=Y
  else
    echo "Beginning validation of $swdPkgDesc..." >> $swdPkgLog
  fi

  echo BUILDSHEET is $BUILDSHEET >> $swdPkgLog
  date >> $swdPkgLog
###################################################################
#*#*#*#*#*#* END ESD PACKAGE INITIALIZATION
###################################################################

# ********** RETURN CODE INFORMATION ******************************
  # NON-SUCCESS
    function NO_INST_SPACE {
      noInstSpace=true
      echo . >> $swdPkgLog
      echo "Insufficient INSTALLATION SPACE." >> $swdPkgLog
    }

  # NON-SUCCESS
    function ALREADY_INSTALLED {
      echo . >> $swdPkgLog
      echo "^^^ERROR: ALREADY INSTALLED^^^" >> $swdPkgLog
      echo "$swdPkgDesc is ALREADY INSTALLED." >> $swdPkgLog
      echo "Returning to commit script with \$rc = 3..." >> $swdPkgLog
      echo "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-" >> $swdPkgLog
      return 3
    }

  # NON-SUCCESS
    function ERR {
      echo . >> $swdPkgLog
      echo "Package Operation for $swdPkgDesc FAILED." >> $swdPkgLog
      echo "Returning to commit script with \$rc = 5..." >> $swdPkgLog
      echo "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-" >> $swdPkgLog
      return 5
    }

  # NON-SUCCESS
    function PREREQ_NOT_MET {
      prereqNotMet=true
      echo . >> $swdPkgLog
      echo "A pre-requisite was NOT met." >> $swdPkgLog
    }

  # NON-SUCCESS
    function OS_PREREQ_NOT_MET {
      prereqNotMet=true
      echo . >> $swdPkgLog
      echo "A pre-requisite was NOT met." >> $swdPkgLog
      echo "Returning to commit script with \$rc = 8..." >> $swdPkgLog
      echo "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-" >> $swdPkgLog
      return 8
    }

  # NON-SUCCESS
    function PRECONFIG_FAILED {
      echo . >> $swdPkgLog
      echo "Pre-installation configuration FAILED." >> $swdPkgLog
      echo "Returning to commit script with \$rc = 6..." >> $swdPkgLog
      echo "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-" >> $swdPkgLog
      return 6
    }

  # NON-SUCCESS
    function POSTCONFIG_FAILED {
      echo . >> $swdPkgLog
      echo "Post-installation configuration FAILED." >> $swdPkgLog
      echo "Returning to commit script with \$rc = 7..." >> $swdPkgLog
      echo "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-" >> $swdPkgLog
      return 7
    }

  # NON-SUCCESS
    function UNSUPPORTED_BCK_LVL_VER {
      echo . >> $swdPkgLog
      echo "Unsupported back level version was found." >> $swdPkgLog
      echo "Returning to commit script with \$rc = 17..." >> $swdPkgLog
      echo "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-" >> $swdPkgLog
      return 17
    }

  # NON-SUCCESS
    function BCK_LVL_VER_UNINSTALL_FAILED {
      echo . >> $swdPkgLog
      echo "Back level version uninstallation FAILED." >> $swdPkgLog
      echo "Returning to commit script with \$rc = 18..." >> $swdPkgLog
      echo "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-" >> $swdPkgLog
      return 18
    }

  # NON-SUCCESS
    function NO_CURRENT_VERSION_CHK_AVAILABLE {
      echo . >> $swdPkgLog
      echo "^^^ERROR: No current version check is available.^^^" >> $swdPkgLog
      echo "Returning to commit script with \$rc = 21..." >> $swdPkgLog
      echo "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-" >> $swdPkgLog
      return 21
    }

  # NON-SUCCESS
    function NO_INSTALL_VERIFICATION_CHK_AVAILABLE {
      echo . >> $swdPkgLog
      echo "^^^ERROR: No installation verification check is available.^^^" >> $swdPkgLog
      echo "Returning to commit script with \$rc = 22..." >> $swdPkgLog
      echo "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-" >> $swdPkgLog
      return 22
    }

  # NON-SUCCESS
    function NEWER_VER_INSTALLED {
      echo . >> $swdPkgLog
      echo "Newer version is installed." >> $swdPkgLog
      echo "Returning to commit script with \$rc = 23..." >> $swdPkgLog
      echo "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-" >> $swdPkgLog
      return 23
    }

  # NON-SUCCESS
    function BCK_LVL_VER_INSTALLED {
      echo . >> $swdPkgLog
      echo "Back level version is installed." >> $swdPkgLog
      echo "Returning to commit script with \$rc = 24..." >> $swdPkgLog
      echo "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-" >> $swdPkgLog
      return 24
    }

  # NON-SUCCESS
    function PROCESS_OR_SRVC_NT_RUNNING {
      echo . >> $swdPkgLog
      echo "Process or service is NOT running." >> $swdPkgLog
      echo "Returning to commit script with \$rc = 25..." >> $swdPkgLog
      echo "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-" >> $swdPkgLog
      return 25
    }

  # NON-SUCCESS
    function AGENT_NT_CONNECTED {
      echo . >> $swdPkgLog
      echo "Agent NOT connected." >> $swdPkgLog
      echo "Returning to commit script with \$rc = 26..." >> $swdPkgLog
      echo "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-" >> $swdPkgLog
      return 26
    }

  # NON-SUCCESS
    function INITIAL_SCN_FAILED {
      echo . >> $swdPkgLog
      echo "Initial scan FAILED." >> $swdPkgLog
      echo "Returning to commit script with \$rc = 27..." >> $swdPkgLog
      echo "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-" >> $swdPkgLog
      return 27
    }

  # SUCCESS
    #SKIP_INSTALL HAS RC=0 BUT CAN BE SET TO 12 UPON CUSTOMER REQUEST
    function SKIP_INSTALL {
      echo . >> $swdPkgLog
      echo "^^^SKIP INSTALL^^^" >> $swdPkgLog
      echo "Installation of $swdPkgDesc is NOT needed." >> $swdPkgLog
      echo "Returning to commit script with \$rc = 0..." >> $swdPkgLog
      #echo "Returning to commit script with \$rc = 12..." >> $swdPkgLog
      echo "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-" >> $swdPkgLog
      #return 12
      return 0
    }

  # SUCCESS
    function OK {
      echo . >> $swdPkgLog
      echo "^^^SUCCESS^^^" >> $swdPkgLog
      echo "Package Operation for $swdPkgDesc completed SUCCESSFULLY." >> $swdPkgLog
      echo "Returning to commit script with \$rc = 0..." >> $swdPkgLog
      echo "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-" >> $swdPkgLog
      return 0
    }

  # SUCCESS
    function OK_CUR_VER_CHK {
      echo . >> $swdPkgLog
      echo "Package Operation for $swdPkgDesc completed SUCCESSFULLY." >> $swdPkgLog
      echo "Returning to commit script with \$rc = 0..." >> $swdPkgLog
      echo "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-" >> $swdPkgLog
      return 0
    }

  # MOSTLY FOR SECURITY ADVISORIES
    function CREATE_SIG_FILE {
      sig_file=$sigfile

      echo . >> $swdPkgLog
      echo "Creating signature file..." >> $swdPkgLog

      mkdir -p -m 755 /var/.SWDist_Sig
      cp $pkgDir/$sig_file /var/.SWDist_Sig
      chmod 755 /var/.SWDist_Sig/$sig_file

      ls -l /var/.SWDist_Sig/$sig_file >> $swdPkgLog

      return 0
    }

  # Error Executing Admin Script
    function ADMIN_SCRIPT_FAILED {
      echo . >> $swdPkgLog
      echo "ERROR: Administrative script failed." >> $swdPkgLog
      echo "Returning to commit script with \$rc = 30..." >> $swdPkgLog
      echo "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-" >> $swdPkgLog
      return 30
    }


  # Verifies file ownership and permission
    function VERIFY_FILE {
      filepath=$1
      user=$2
      perms=$3

      if [[ ! -e $filepath ]]
      then
        echo "   $filepath does not exist" >> $swdPkgLog
        return 1
      fi

      if [[ -d $filepath ]]
      then
        PERMS="`ls -dl $filepath | awk '{print $1}'`"
        OWNER="`ls -dl $filepath | awk '{print $3}'`"
        GROUP="`ls -dl $filepath | awk '{print $4}'`"
      else
        PERMS="`ls -l $filepath | awk '{print $1}'`"
        OWNER="`ls -l $filepath | awk '{print $3}'`"
        GROUP="`ls -l $filepath | awk '{print $4}'`"
      fi
      echo "   -----" >> $swdPkgLog
      echo "   File:  $filepath" >> $swdPkgLog
      echo "   Owner: $OWNER:$GROUP" >> $swdPkgLog
      echo "   Perms: $PERMS" >> $swdPkgLog
      echo "   -----" >> $swdPkgLog

      FOUND=`find $filepath -user $user -perm $perms`

      if [[ $FOUND = "" ]]
      then
        echo "   ERROR: File must be owned by $user with $perms permissions" >> $swdPkgLog
        return 2
      else
        echo "   $filepath has the correct permissions" >> $swdPkgLog
      fi

      return 0
    }
# ********** END RETURN CODE INFORMATION **************************

# ********** PACKAGE SPECIFIC FUNCTIONS ***************************

function Edit_Config_Files
{

  typeset -a ARRAY

  ConfigFile=$1
  RespFile=$2

  i=0
  { while read line;do
    echo "${line}" | grep -v "^#." > /dev/null
    if [[ $? -eq 0 ]]
    then
      ARRAY[$i]=`echo "${line}" | grep -v "^#."`
      let i=$i+1
    fi
  done } < $RespFile

  cp $ConfigFile $tempFile

  for Option in "${ARRAY[@]}"; 
  do  
    
    echo "$Option" | grep "^\-b" > /dev/null
    if [[ $? -eq 0 ]]
    then
      rc=$?
    else
      cat $tempFile | grep "^$Option" > /dev/null
      rc=$?
    fi
    value="$Option"
    value2="$Option"

    if [[ $rc -eq 0 ]]
    then
      if [[ -f "${swdWorkDir}/fars_tmp" ]]
      then
        rm ${swdWorkDir}/fars_tmp 2> /dev/null
      fi
      myvariable="$Option"
      mynewvariable_val="$value"  
      { while read line;do

        caracter=`echo "${mynewvariable_val}" | awk '{print $1}' | tr -d ' '` 

        if [[ "$caracter" != "-b" ]]
        then
          variable=`echo ${line} | grep -E "^${mynewvariable_val}$" | awk -F "=" '$1!~/#[[:space:]]/ {print $1}' | tr -d ' ' | grep -E "^${myvariable}$"`
        else
          variable=`echo ${line} | grep "^\-b"`
        fi
          newline="${mynewvariable_val}"

        if [[ "$variable" != "" ]]; then
            echo "$newline" >> ${swdWorkDir}/fars_tmp
        else 
          if [[ "${line}" != "" ]]; then
            echo "$line" >> ${swdWorkDir}/fars_tmp
          fi
        fi
      done } < $tempFile

      cp ${swdWorkDir}/fars_tmp $tempFile >> $swdPkgLog 2>&1

    else
      echo "$value2" >> $tempFile
    fi
  done

  mv $tempFile $ConfigFile >> $swdPkgLog 2>&1

}

function RESTORE_FILE
{
  failrestoration=0
  IFS=" "
  filestorestore="audit.rules rc.local"

  for file in $filestorestore; do

    if [[ $file = "audit.rules" ]]
    then
      pathfile="$path_audit"
    elif [[ $file = "rc.local" ]]
    then
      pathfile="/etc/rc.d"
    fi

    echo . >> $swdPkgLog
    echo "Restoring $pathfile/backout.qradar/$file to $pathfile/$file" >> $swdPkgLog 2>&1
    echo "...CMD: cp -fp $pathfile/backout.qradar/$file $pathfile/$file" >> $swdPkgLog
    cp -fp $pathfile/backout.qradar/$file $pathfile/$file >> $swdPkgLog 2>&1
    if [[ $? -ne 0 ]]
    then
      failrestoration=`expr $failrestoration + 1`
      echo "...Failed to restore `echo ${file} | awk -F/ '{print $NF}'`." >> $swdPkgLog
    else
      echo "...File `echo $file | awk -F/ '{print $NF}'` restored successfully." >> $swdPkgLog
    fi
  done

  if [[ $failrestoration -ge 1 ]];then
    echo "^^^ERROR: Failed to restore one or more file(s) from backuot directory.^^^" >> $swdPkgLog
    ERR
    fctnRC=$?
    if [[ $fctnRC -ne 0 ]]
    then
      return $fctnRC
    fi
  fi
 }

 function get_permits
 {

    #file=with path inluded Ex: /etc/redhat-release

    file=$1

    owner=`ls -l "$file" | awk '{print $3}'`
    group=`ls -l "$file" | awk '{print $4}'`

    owner_permission=0
    group_permission=0
    others_permission=0

    for ((i=2; i<=10; i++))
    do

      permission=`ls -l "$file" | awk '{print $1}' | awk -F "" -v i=$i '{print $i}'`
      case $i in

        [2-4])
          case $permission in
            [r]) let owner_permission=$owner_permission+4;;
            [w]) let owner_permission=$owner_permission+2;;
            [x]) let owner_permission=$owner_permission+1;;
          esac
          ;;
        [5-7])
          case $permission in
            [r]) let group_permission=$group_permission+4;;
            [w]) let group_permission=$group_permission+2;;
            [x]) let group_permission=$group_permission+1;;
          esac
          ;;
        [8-9])
          case $permission in
            [r]) let others_permission=$others_permission+4;;
            [w]) let others_permission=$others_permission+2;;
            [x]) let others_permission=$others_permission+1;;
          esac
          ;;
        10)
          case $permission in
            [r]) let others_permission=$others_permission+4;;
            [w]) let others_permission=$others_permission+2;;
            [x]) let others_permission=$others_permission+1;;
          esac
          ;;
      esac
    done 

 }
# ********** END PACKAGE SPECIFIC FUNCTIONS ***********************

###################################################################
#*#*#* O/S VERSION CHECK *#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#
###################################################################
if [[ "$swdNormalInst" = "Y" ]] || [[ "$swdOSVerChk" = "Y" ]] || [[ "$swdOSVerChk" = "YES" ]]
then
# ********** O/S VERSION CHECK ************************************
  preReqVar=`cat /etc/redhat-release | awk -F'(' '{print $1}' | awk '{print $NF}'`

  echo . >> $swdPkgLog
  echo "Beginning OS version check for Red Hat Enterprise Linux..." >> $swdPkgLog

  if [ `echo $preReqVar | grep -c 2.1` = 1 ]
  then
    os=2.1
    echo "...Red Hat Enterprise Linux $os was found." >> $swdPkgLog
    echo "^^^ERROR: This package is not supported fot RedHat Linux $os.^^^" >> $swdPkgLog
    OS_PREREQ_NOT_MET
    fctnRC=$?
    if [[ $fctnRC -ne 0 ]]
    then
       return $fctnRC
    fi
  elif [[ `echo $preReqVar | grep -c ^3` = 1 ]]
  then
    os=3.0
    echo "...Red Hat Enterprise Linux $preReqVar was found." >> $swdPkgLog
    echo "^^^ERROR: This package is not supported fot RedHat Linux $preReqVar.^^^" >> $swdPkgLog
    OS_PREREQ_NOT_MET
    fctnRC=$?
    if [[ $fctnRC -ne 0 ]]
    then
       return $fctnRC
    fi
  elif [[ `echo $preReqVar | grep -c ^4` = 1 ]]
  then
    os=4.0
    echo "...Red Hat Enterprise Linux $preReqVar was found." >> $swdPkgLog
    echo "^^^ERROR: This package is not supported fot RedHat Linux $preReqVar.^^^" >> $swdPkgLog
    OS_PREREQ_NOT_MET
    fctnRC=$?
    if [[ $fctnRC -ne 0 ]]
    then
       return $fctnRC
    fi
  elif [[ `echo $preReqVar | grep -c ^5` = 1 ]]
  then
    os=5.0
    echo "...Red Hat Enterprise Linux $preReqVar was found." >> $swdPkgLog
  elif [ `echo $preReqVar | grep -c ^6` = 1 ]
  then
    os=6.0
    echo "...Red Hat Enterprise Linux $preReqVar was found." >> $swdPkgLog
  elif [ `echo $preReqVar | grep -c ^7` = 1 ]
  then
    os=7.0
    echo "...Red Hat Enterprise Linux $preReqVar was found." >> $swdPkgLog
  elif [ `echo $preReqVar | grep -c ^8` = 1 ]
  then
    os=8.0
    echo "...Red Hat Enterprise Linux $preReqVar was found." >> $swdPkgLog
  else
    echo "^^^ERROR: Could not determine version of Red Hat; aborting the install.^^^" >> $swdPkgLog
    OS_PREREQ_NOT_MET
    fctnRC=$?
    if [[ $fctnRC -ne 0 ]]
    then
      return $fctnRC
    fi
  fi
# ********** END O/S VERSION CHECK ********************************

# ********** O/S ARCH CHECK ***************************************
  ARCH_CHECK_TMP=`uname -m`;
  ARCH_CHECK=`echo $ARCH_CHECK_TMP | tr '[:upper:]' '[:lower:]'`
  ARCH_CHECK=`echo $ARCH_CHECK | sed 's/ //g'`
  VALID_ARCH=`echo $ARCH_CHECK | egrep -e '(^i|^x)'`
  if [[ "$VALID_ARCH" = "" ]]
  then
    echo "^^^ERROR: Hardware platform, ${ARCH_CHECK_TMP}, does not match with binaries for the package; aborting the install.^^^" >> $swdPkgLog
    OS_PREREQ_NOT_MET
    fctnRC=$?
    if [[ $fctnRC -ne 0 ]]
    then
      return $fctnRC
    fi
  fi

  OS_ARCH=`uname -m | grep x86_64`;
  OS_ARCH=`echo $OS_ARCH | tr '[:upper:]' '[:lower:]'`
  OS_ARCH=`echo $OS_ARCH | sed 's/ //g'`
  if [[ "$linArch" = "all" ]]
  then
    echo "32-bit and 64-bit architectures are supported..." >>$swdPkgLog
  else
    if [[ "$OS_ARCH" != "" ]] && [[ "$linArch" = "64-bit" ]]
    then
      echo "...Found 64-bit architecture..." >>$swdPkgLog
      echo "...Expecting 64-bit architecture..." >>$swdPkgLog
    elif [[ "$OS_ARCH" != "" ]] && [[ "$linArch" = "32-bit" ]]
    then
      echo "^^^ERROR: Found 64-bit RHEL architecture, expecting 32-bit RHEL architecture; aborting the install.^^^" >>$swdPkgLog
      OS_PREREQ_NOT_MET
      fctnRC=$?
      if [[ $fctnRC -ne 0 ]]
      then
        return $fctnRC
      fi
    elif [[ "$OS_ARCH" = "" ]] && [[ "$linArch" = "32-bit" ]]
    then
      echo "...Found 32-bit architecture..." >>$swdPkgLog
      echo "...Expecting 32-bit architecture..." >>$swdPkgLog
    elif [[ "$OS_ARCH" = "" ]] && [[ "$linArch" = "64-bit" ]]
    then
      echo "^^^ERROR: Found 32-bit RHEL architecture, expecting 64-bit RHEL architecture; aborting the install.^^^" >>$swdPkgLog
      OS_PREREQ_NOT_MET
      fctnRC=$?
      if [[ $fctnRC -ne 0 ]]
      then
        return $fctnRC
      fi
    else
      echo "^^^ERROR: INVALID ARCHITECTURE TYPE - $linArch.^^^" >>$swdPkgLog
      OS_PREREQ_NOT_MET
      fctnRC=$?
      if [[ $fctnRC -ne 0 ]]
      then
        return $fctnRC
      fi
    fi
  fi
# ********** END O/S ARCH CHECK ***********************************
fi
###################################################################
#*#*#* END O/S VERSION CHECK *#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#
###################################################################

# ********** LIST / SET BUILDSHEET DEFAULT VARIABLE VALUES ********
	echo . >> $swdPkgLog
	echo "Verifying if BUILDSHEET exists..." >> $swdPkgLog

	if [[ -f $BUILDSHEET ]]
	then
		echo "...Buildsheet was found, setting variables." >> $swdPkgLog
		tail2syslog_QradarIP=`grep btbs.tail2syslog_QradarIP $BUILDSHEET | cut -d= -f2`
		tail2syslog_Globs=`grep btbs.tail2syslog_Globs $BUILDSHEET | cut -d= -f2`
		tail2syslog_ArchiveDir=`grep btbs.tail2syslog_ArchiveDir $BUILDSHEET | cut -d= -f2`
		tail2syslog_DeletionThreshold=`grep btbs.tail2syslog_DeletionThreshold $BUILDSHEET | cut -d= -f2`
    tail2syslog_only=`grep btbs.tail2syslog_only $BUILDSHEET | cut -d= -f2`
	else
		echo "^^^ERROR: BUILDSHEET was not found.^^^" >> $swdPkgLog
		ERR
		fctnRC=$?
		if [[ $fctnRC -ne 0 ]]
		then
			return $fctnRC
		fi
	fi

  echo "Current BUILDSHEET:" >> $swdPkgLog
  echo "************************************************************" >> $swdPkgLog
  echo "tail2syslog_QradarIP=$tail2syslog_QradarIP" >> $swdPkgLog
  echo "tail2syslog_Globs=$tail2syslog_Globs" >> $swdPkgLog
  echo "tail2syslog_ArchiveDir=$tail2syslog_ArchiveDir" >> $swdPkgLog
  echo "tail2syslog_DeletionThreshold=$tail2syslog_DeletionThreshold" >> $swdPkgLog
  echo "tail2syslog_only=$tail2syslog_only" >> $swdPkgLog
  echo "************************************************************" >> $swdPkgLog

# ********** END LIST / SET BUILDSHEET DEFAULT VARIABLE VALUES ****

###################################################################
#*#*#* SPACE CHECKS/PRE-REQUISITE CHECKS *#*#*#*#*#*#*#*#*#*#*#*#*#
###################################################################
if [[ "$swdNormalInst" = "Y" ]] || [[ "$swdSpcChk" = "Y" ]] || [[ "$swdSpcChk" = "YES" ]]
then
  if [[ "$swdSpcChk" = "Y" ]] || [[ "$swdSpcChk" = "YES" ]]
  then
    whichLog=$swdSpcChkLog
  else
    whichLog=$swdPkgLog
  fi

  ##################### REMOVE THIS SPACE CHECK CODE IF NOT NEEDED #####################
  #************************************************************************************#
  ############################### SPACE CHECK CODE START ###############################
  #************************************************************************************#
    echo . >> $swdPkgLog

    ##################################################################################
    # If you need to check for the existence of mounted filesystem, use and modify   #
    # the following code.  $CHECK_DIR represents the btbs variable or the filesystem #
    # of which you need to check.                                                    #
    ##################################################################################
    #echo .>> $swdPkgLog
    #echo "Checking for filesytem $CHECK_DIR ..." >> $swdPkgLog
    #echo .>> $swdPkgLog

    #df -k | grep -w "$CHECK_DIR$"  >> $swdPkgLog 2>&1
    #rc=$?
    #if [[ $rc -ne 0 ]]
    #then
    #   echo "^^^ERROR: $CHECK_DIR is not a mounted filesystem.^^^" >> $swdPkgLog
    #   prereqNotMet=true
    #   PREREQ_NOT_MET
    #fi

    echo "Creating and Adding File for use in SpaceCheck..." >> $swdPkgLog
    #####################################################################################
    # Instructions:                                                                     #
    # Copy the directory and size (in 1024-Byte blocks) into the SpaceRequirement       #
    # file, using the echo command, in format shown below:                              #
    # Example:                                                                          #
    #     #### SpaceRequirement file creation ########                                  #
    #          echo $AgentInstallPath:56320 > $swdWorkDir/SpaceRequirement              #
    #          echo $AgentTempPath:71680 >> $swdWorkDir/SpaceRequirement                #
    #     #### END SpaceRequirement file creation ####                                  #
    #                                                                                   #
    # NOTE: Always use the btbs variables, unless there is a strict requirement         #
    #       from the customer to use a specific directory that is not to be changed.    #
    #                                                                                   #
    # NOTE: Make sure that the first echo always uses a single ">" (overwrite)          #
    #       All lines after the first uses a double ">>" (append)                       #
    #                                                                                   #
    # Please create your SpaceRequirement file below.                                   #
    #####################################################################################
    #### SpaceRequirement file creation ########
      echo /opt:1024 > $swdWorkDir/SpaceRequirement1M
      echo /opt:51200 > $swdWorkDir/SpaceRequirement50M
    #### END SpaceRequirement file creation ####

    #***********************************************************************************#
    ## Make sure to set noInstSpace=true and call NO_INST_SPACE after setting an proper
    ## and descriptive error message.
    #***********************************************************************************#
    echo . >> $swdPkgLog
    echo "Beginning Space check..." >> $swdPkgLog

    . ${pkgDir}/SpaceChecks.sh ${swdWorkDir}/SpaceRequirement1M
  	fctnRC=$?
  	if [[ $fctnRC -ne 0 ]]
  	then
  		echo "^^^ERROR: There is not enough space in the system to meet the requirements.^^^" >> $swdPkgLog
  		noInstSpace=true
  		NO_INST_SPACE
  	fi

  	. ${pkgDir}/SpaceChecks.sh ${swdWorkDir}/SpaceRequirement50M
  	fctnRC=$?
  	if [[ $fctnRC -ne 0 ]]
  	then
  		echo "^W^WARNING: /etc/security/audit has less than 50 MB of space.^W^" >> $swdPkgLog
  	fi

    echo . >> $swdPkgLog
  	echo "Removing \"SpaceRequirement1M\" used for space checking..." >> $swdPkgLog
  	rm -rf "${swdWorkDir}/SpaceRequirement1M" >> $swdPkgLog 2>&1
  	rc=$?
  	if [[ $rc -eq 0 ]]
  	then
  		echo "SpaceRequirement1M was removed successfully." >> $swdPkgLog
  	else
  		echo "SpaceRequirement1M could not be removed." >> $swdPkgLog
  	fi

  	echo . >> $swdPkgLog
  	echo "Removing \"SpaceRequirement50M\" used for space checking..." >> $swdPkgLog
  	rm -rf "${swdWorkDir}/SpaceRequirement50M" >> $swdPkgLog 2>&1
  	rc=$?
  	if [[ $rc -eq 0 ]]
  	then
  		echo "SpaceRequirement1M was removed successfully." >> $swdPkgLog
  	else
  		echo "SpaceRequirement1M could not be removed." >> $swdPkgLog
  	fi
  #************************************************************************************#
  ################################ SPACE CHECK CODE END ################################
  #************************************************************************************#
  whichLog=$swdPkgLog

  # ********** BUILDSHEET VARIABLE VALUE VERIFICATION ***************

   ## BTBS CHECK 01 *********************************************** ##
	echo . >> $swdPkgLog
	echo "Checking tail2syslog_QradarIP..." >> $swdPkgLog
	if [[ ! -z "$tail2syslog_QradarIP" ]]
	then
    . ${pkgDir}/verifyIPFormat.sh $tail2syslog_QradarIP >> $swdPkgLog 2>&1
    rc=$?
    if [[ $rc -ne 0 ]]
    then
      echo "^^^ERROR: The btbs variable tail2syslog_QradarIP have not valid ip, you have to enter a valid ip.^^^" >> $swdPkgLog
      prereqNotMet=true
      PREREQ_NOT_MET
    fi
  else
		echo "^^^ERROR: The btbs variable tail2syslog_QradarIP is empty, you have to complete this field. The default value are \"0.0.0.0\" ^^^" >> $swdPkgLog
		prereqNotMet=true
		PREREQ_NOT_MET
	fi

  ## BTBS CHECK 02 *********************************************** ##
  echo . >> $swdPkgLog
  echo "Checking tail2syslog_Globs..." >> $swdPkgLog
  if [[ -z "$tail2syslog_Globs" ]]
  then
    echo "^^^ERROR: The btbs variable tail2syslog_Globs is empty, you have to complete this field. The default value are \"/var/log/audit/audit.log\" ^^^" >> $swdPkgLog
    prereqNotMet=true
    PREREQ_NOT_MET
  fi

  ## BTBS CHECK 03 *********************************************** ##
  echo . >> $swdPkgLog
  echo "Checking tail2syslog_DeletionThreshold..." >> $swdPkgLog
  if [[ ! -z "$tail2syslog_DeletionThreshold" ]]
  then
    echo $tail2syslog_DeletionThreshold | grep [A-Za-z] > /dev/null
    rc=$?
    if [[ $rc -eq 0 ]]
    then
      echo "^^^ERROR: tail2syslog_DeletionThreshold is not a numeric value.^^^" >> $swdPkgLog
      prereqNotMet=true
      PREREQ_NOT_MET
    fi
  else
    echo "^^^ERROR: The btbs variable tail2syslog_DeletionThreshold is empty, you have to complete this field. The default value are \"0\" ^^^" >> $swdPkgLog
    prereqNotMet=true
    PREREQ_NOT_MET
  fi  

  ## BTBS CHECK 04 *********************************************** ##
  echo . >> $swdPkgLog
  echo "Checking tail2syslog_only..." >> $swdPkgLog
  if [[ -z "$tail2syslog_only" ]]
  then
    echo "^^^ERROR: The btbs variable tail2syslog_only is empty, you have to complete this field. The default value are \"no\" ^^^" >> $swdPkgLog
    prereqNotMet=true
    PREREQ_NOT_MET
  else
    case ${tail2syslog_only} in
    [Yy][Ee][Ss]) tail2syslog_only=YES;;
    [Yy]) tail2syslog_only=YES;;
    [Nn][Oo]) tail2syslog_only=NO;;
    [Nn]) tail2syslog_only=NO;;
    *)
    echo "^^^ERROR: btbs.tail2syslog_only has an invalid value: ($tail2syslog_only). Valid values are 'yes' or 'no'.^^^" >> $swdPkgLog
    prereqNotMet=true
    PREREQ_NOT_MET
    ;;
    esac
  fi
  # ********** END BUILDSHEET VARIABLE VALUE VERIFICATION ***********

  #***********************************************************************************#
  ######################### PRE-REQUSITE CHECKS START #################################
  #***********************************************************************************#
  ## Make sure to set prereqNotMet=true and call PREREQ_NOT_MET after setting an proper
  ## and descriptive error message.
  #***********************************************************************************#
  # For example:
   echo . >> $swdPkgLog
   echo "Beginning prerequisite check for $swdPkgDesc..." >> $swdPkgLog
  	echo . >> $swdPkgLog
  # CMD1=telnet
  # echo "Checking if $CMD1 is present on the system..." >> $swdPkgLog
  # which $CMD1 >> $swdPkgLog 2>&1
  # which_rc=$?
  # if [[ $which_rc -ne 0 ]]
  # then
  #   echo "^^^ERROR: $CMD1 was not found on the system. Port Checking/IP Checking requires telnet.^^^"  >> $swdPkgLog
  #   prereqNotMet=true
  #   PREREQ_NOT_MET
  # else
  #   echo "$CMD1 was found..." >> $swdPkgLog
  # fi
  #
  # etc ...

	echo . >> $swdPkgLog
	echo "Checking if perl-5.8.8 package or greater is installed." >> $swdPkgLog
	PerlVersion=`rpm -qa | grep ^perl-[0-9] | sed 's/^perl-\(.*\)-.*/\1/ ; s/\.//g'` >> $swdPkgLog 2>&1
	
	if [[ $PerlVersion -lt 588 ]]
	then
		echo "^^^ERROR: perl-5.8.8 package or greater is not installed and it is requiered to continue.^^^"  >> $swdPkgLog
		prereqNotMet=true
		PREREQ_NOT_MET
	else
		echo "Perl package was found installed in the system" >> $swdPkgLog
	fi

	echo . >> $swdPkgLog

	echo "Checking for audit library" >> $swdPkgLog
	rpm -qa | grep -c ^audit-[0-9] >> $swdPkgLog 2>&1
	rc=$?
	if [[ $rc -ne 0 ]]
	then
		echo "^^^ERROR: Audit library Package is not installed and it is requiered to continued installation.^^^"  >> $swdPkgLog
		prereqNotMet=true
		PREREQ_NOT_MET
	else
		echo "Audit library Package was found installed in the system" >> $swdPkgLog
	fi

  echo . >> $swdPkgLog

  echo "Checking SELinux status" >> $swdPkgLog
  SELinuxStatus=`getenforce |grep "Permissive"` >> $swdPkgLog 2>&1
  if [[ "$SELinuxStatus" != "Permissive" ]]
  then
    echo "^W^WARNING: SELinux is not in \"Permissive\" mode.^W^"  >> $swdPkgLog
  else
    echo "SELinux are in \"$SELinuxStatus\" mode" >> $swdPkgLog
  fi


### Change in version V7.3


   echo "." >> $swdPkgLog
   echo "Checking if unzip is installed" >> $swdPkgLog

  echo "CMD: rpm -q unzip" >> $swdPkgLog
  rpm -q unzip >> $swdPkgLog 2>&1
  rc=$?
  echo "RC=${rc}" >> $swdPkgLog
  if [[ ${rc} -ne 0 ]]; then
    echo . >> $swdPkgLog
    echo "^^^ERROR: unzip was not found installed on the system.^^^"  >> $swdPkgLog
    prereqNotMet=true
    PREREQ_NOT_MET
    else
    echo "unzip was found installed..." >> $swdPkgLog
  fi


### Change in version V7.3 END
	
  #***********************************************************************************#
  ######################### PRE-REQUSITE CHECKS END ###################################
  #***********************************************************************************#

fi
###################################################################
#*#*#* END SPACE CHECKS/PRE-REQUISITE CHECKS *#*#*#*#*#*#*#*#*#*#*#
###################################################################

###################################################################
#*#*#* EXIT IF PREREQ_NOT_MET or NO_INST_SPACE *#*#*#*#*#*#*#*#*#*#
if [[ "$prereqNotMet" = "true" ]]
then
  echo "Returning to commit script with \$rc = 8..." >> $swdPkgLog
  echo "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-" >> $swdPkgLog
  return 8
fi
if [[ "$noInstSpace" = "true" ]]
then
  echo "Returning to commit script with \$rc = 2..." >> $swdPkgLog
  echo "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-" >> $swdPkgLog
  return 2
fi
###################################################################

###################################################################
#*#*#* INSTALL SECTION *#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#
###################################################################
if [[ "$swdNormalInst" = "Y" ]]
then
# ********** ALREADY INSTALLED INFORMATION ************************
  echo . >> $swdPkgLog
  echo "Beginning already installed check..." >> $swdPkgLog
  echo "." >> $swdPkgLog
  already=0
  echo "Already Installed Check for $swdPkgDesc." >>$swdPkgLog
  echo "Checking if /var/.SWDist_Sig/$sigfile exist..." >> $swdPkgLog
  if [[ -f /var/.SWDist_Sig/$sigfile ]]
  then
    echo "/var/.SWDist_Sig/$sigfile file found, This package is already installed and will be overwritten." >> $swdPkgLog
    already=1
  else
    echo "/var/.SWDist_Sig/$sigfile file not found. Package $swdPkgDesc Install Will Continue." >> $swdPkgLog
  fi
  echo . >> $swdPkgLog
# ********** END ALREADY INSTALLED INFORMATION ********************

# ********** UNINSTALL PREVIOUS VERSION  **************************
  # Uninstall Application

# ********** END UNINSTALL PREVIOUS VERSION ***********************

# ********** PRE-INSTALLATION CONFIGURATION ***********************
	echo "Checking if the tail2syslog process is running.  If it is running, the script will kill the process first before proceeding with the install. " >> $swdPkgLog
	process_tail2syslog=`ps -ef | grep -v grep | grep tail2syslog | awk '{print $2}'` 
	sleep 10
	if [[ ! -z $process_tail2syslog ]]
	then
	kill $process_tail2syslog >> $swdPkgLog 2>&1
	echo Killed process ID $process_tail2syslog.... >> $swdPkgLog
	else
	echo "Process tail2syslog not found, continue with instalation. " >> $swdPkgLog	
	fi

### Change in version V7.3

#// Update the code for the backup/edit/restore of the audit.rules file

echo ".">> $swdPkgLog
echo "Setting audit path. " >> $swdPkgLog

if [[ $os = "7.0" || $os = "8.0" ]]; then
    path_audit=/etc/audit/rules.d
else
    path_audit=/etc/audit
fi


#// Make /etc/rc.d/rc.local executable (chmod +x /etc/rc.d/rc.local) 

echo ".">> $swdPkgLog
echo "Making rc.local executable with command chmod +x /etc/rc.d/rc.local" >> $swdPkgLog
chmod +x /etc/rc.d/rc.local >> $swdPkgLog 2>&1
	fctnRC=$?
	if [[ $fctnRC -ne 0 ]]
	then
		echo "^^^ERROR: an error has ocurred setting execute permissions to file rc.local.^^^"  >> $swdPkgLog
		PRECONFIG_FAILED
		fctnRC=$?
		if [[ $fctnRC -ne 0 ]]
		then
				return $fctnRC
		fi
	else
		echo "Set permissions successfully." >> $swdPkgLog
	fi

# Verify that /var/log/audit directory exists.  

echo ".">> $swdPkgLog
echo "Verifying that /var/log/audit directory exists" >> $swdPkgLog

#Directory Verification
if [[ -d "/var/log/audit" ]]
then
echo "/var/log/audit directory exists"  >> $swdPkgLog
else
#Directory creation
	echo "Directory /var/log/audit does not exist, attempting to create it" >> $swdPkgLog
	mkdir /var/log/audit >> $swdPkgLog 2>&1
	fctnRC=$?
	if [[ $fctnRC -ne 0 ]]
	then
		echo "^^^ERROR: an error has ocurred creating directory /var/log/audit.^^^"  >> $swdPkgLog
		PRECONFIG_FAILED
		fctnRC=$?
		if [[ $fctnRC -ne 0 ]]
		then
				return $fctnRC
		fi
	else
		echo "Directory created successfully." >> $swdPkgLog
	fi
#Permissions
	echo "Setting permissions to directory" >> $swdPkgLog
	chmod 750 /var/log/audit >> $swdPkgLog 2>&1
	fctnRC=$?
	if [[ $fctnRC -ne 0 ]]
	then
		echo "^^^ERROR: an error has ocurred setting permissions chmod 750 /var/log/audit.^^^"  >> $swdPkgLog
		PRECONFIG_FAILED
		fctnRC=$?
		if [[ $fctnRC -ne 0 ]]
		then
				return $fctnRC
		fi
	else
		echo "Permissions set successfully." >> $swdPkgLog
	fi

#Ownership
	echo "Setting ownership to directory" >> $swdPkgLog
	chown root:root /var/log/audit >> $swdPkgLog 2>&1
	fctnRC=$?
	if [[ $fctnRC -ne 0 ]]
	then
		echo "^^^ERROR: an error has ocurred setting ownership chown root:root /var/log/audit.^^^"  >> $swdPkgLog
		PRECONFIG_FAILED
		fctnRC=$?
		if [[ $fctnRC -ne 0 ]]
		then
				return $fctnRC
		fi
	else
		echo "Ownership set successfully." >> $swdPkgLog
	fi	
fi

### Change in version V7.3 END 


	echo . >> $swdPkgLog
	echo "Performing file backup before modification" >> $swdPkgLog
	bkpfiles="audit.rules rc.local"

	for bkpfile in $bkpfiles
	do
		if [[ $bkpfile = "audit.rules" ]]
		then
			pathfile="$path_audit"
		elif [[ $bkpfile = "rc.local" ]]
		then
			pathfile="/etc/rc.d"
		fi

	if [[ -f $pathfile/$bkpfile ]]
	then
		if [[ ! -d $pathfile/backout.qradar/ ]]
		then
			echo "Creating $pathfile/backout.qradar" >> $swdPkgLog
			mkdir -p $pathfile/backout.qradar >> $swdPkgLog 2>&1
			fctnRC=$?
			if [[ $fctnRC -ne 0 ]]
			then
				echo "^^^ERROR: an error has ocurred creating $pathfile/backout.qradar, the installation cannot continue.^^^"  >> $swdPkgLog
				PRECONFIG_FAILED
				fctnRC=$?
				if [[ $fctnRC -ne 0 ]]
				then
						return $fctnRC
				fi
			else
				echo "$pathfile/backout.qradar folder was created." >> $swdPkgLog
			fi
		fi

    echo . >> $swdPkgLog
		echo "Performing backup from $pathfile/$bkpfile to $pathfile/backout.qradar/$bkpfile" >> $swdPkgLog
		cp -p $pathfile/$bkpfile $pathfile/backout.qradar/$bkpfile >> $swdPkgLog 2>&1
		fctnRC=$?
		if [[ $fctnRC -ne 0 ]]
		then
			echo "^^^ERROR: an error has ocurred performing backup for $pathfile/$bkpfile to $pathfile/backout.qradar/$bkpfile^^^"  >> $swdPkgLog
			PRECONFIG_FAILED
			fctnRC=$?
			if [[ $fctnRC -ne 0 ]]
			then
				return $fctnRC
			fi
		else
			echo "Backup for $pathfile/$bkpfile done in $pathfile/backout.qradar/$bkpfile" >> $swdPkgLog
		fi
	fi
	done

# ********** END PRE-INSTALLATION CONFIGURATION ******************

# ********** EXECUTE ADMIN BEFORE SCRIPT **************************
  dir=`dirname $swdAdmBefore`

  # Verify directory script_path resides in
  VERIFY_FILE $dir root 0700
  admrc=$?

  if [[ "$admrc" != 0 ]]
  then
    if [[ "$admrc" = 1 ]]
    then
      echo "No customer specific administrative script ($swdAdmBefore) to execute." >> $swdPkgLog
      echo "Now invoking package installation..." >> $swdPkgLog
    else
      echo "^^^ERROR: Incorrect permissions to execute $swdAdmBefore.  Administrative before script failed.^^^" >> $swdPkgLog
      ADMIN_SCRIPT_FAILED
      fctnRC=$?
      if [[ $fctnRC -ne 0 ]]
      then
        return $fctnRC
      fi
    fi
  else
    # Verify admin file (executable)
    VERIFY_FILE $swdAdmBefore root 0700
    admrc=$?

    if [[ "$admrc" != 0 ]]
    then
      if [[ "$admrc" = 1 ]]
      then
        echo "No customer specific administrative script ($swdAdmBefore) to execute." >> $swdPkgLog
        echo "Now invoking package installation..." >> $swdPkgLog
      else
        echo "^^^ERROR: Incorrect permissions to execute $swdAdmBefore.  Administrative before script failed.^^^" >> $swdPkgLog
        ADMIN_SCRIPT_FAILED
        fctnRC=$?
        if [[ $fctnRC -ne 0 ]]
        then
          return $fctnRC
        fi
      fi
    else
      # Execute admin script
      $swdAdmBefore
      admrc=$?

      if [[ "$admrc" != 0 ]]
      then
        echo "^^^ERROR: Executing $swdAdmBefore administrative script, rc = $admrc^^^" >> $swdPkgLog
        ADMIN_SCRIPT_FAILED
        fctnRC=$?
        if [[ $fctnRC -ne 0 ]]
        then
          return $fctnRC
        fi
      else
        echo "Administrative script $swdAdmBefore executed successfully." >> $swdPkgLog
      fi
    fi
  fi
# ********** END EXECUTE ADMIN BEFORE SCRIPT **********************

# ********** INSTALLATION SECTION *********************************

  echo . >> $swdPkgLog

  if [[ "$tail2syslog_only" = "YES" ]]
  then
    echo "Btbs tail2syslog_only is set to yes. All configuration changes to $path_audit/audit.rules will be skiped" >> $swdPkgLog
  else
    echo . >> $swdPkgLog
  	echo "Saving file permissions, group and owner for $path_audit/audit.rules"  >> $swdPkgLog
    get_permits "$path_audit/audit.rules"
  	echo "Writing information to $path_audit/audit.rules"  >> $swdPkgLog
    Edit_Config_Files "$path_audit/audit.rules" "$rspDir/_etc_audit_auditd.rules"
  	fctnRC=$?
  	if [[ $fctnRC -ne 0 ]]
  	then 
  		echo "^^^ERROR: an error has ocurred writing $path_audit/audit.rules.^^^"  >> $swdPkgLog
      RESTORE_FILE
  		ERR
  		fctnRC=$?
  		if [[ $fctnRC -ne 0 ]]
  		then
  			return $fctnRC
  		fi
    else
      echo "Restoring file permissions for $path_audit/audit.rules"  >> $swdPkgLog
      chmod ${owner_permission}${group_permission}${others_permission} "$path_audit/audit.rules" >> $swdPkgLog 2>&1
      fctnRC=$?
      if [[ $fctnRC -ne 0 ]]
      then 
        echo "^^^ERROR: An error has ocurred restoring file permissions for $path_audit/audit.rules^^^"  >> $swdPkgLog
        RESTORE_FILE
        ERR
        fctnRC=$?
        if [[ $fctnRC -ne 0 ]]
        then
          return $fctnRC
        fi
      fi
      echo "Restoring file group and owner for $path_audit/audit.rules"  >> $swdPkgLog
      chown ${owner}":"${group} "$path_audit/audit.rules" >> $swdPkgLog 2>&1
      fctnRC=$?
      if [[ $fctnRC -ne 0 ]]
      then 
        echo "^^^ERROR: An error has ocurred restoring group and owner for $path_audit/audit.rules^^^"  >> $swdPkgLog
        RESTORE_FILE
        ERR
        fctnRC=$?
        if [[ $fctnRC -ne 0 ]]
        then
          return $fctnRC
        fi
      fi
  	fi

    echo . >> $swdPkgLog
    echo "Restarting auditd service." >> $swdPkgLog
    service auditd restart >> $swdPkgLog 2>&1
    fctnRC=$?
    if [[ $fctnRC -ne 0 ]]
    then
      echo "^^^ERROR: an error has ocurred restarting the auditd service. The installation cannot continue.^^^"  >> $swdPkgLog
      RESTORE_FILE
      ERR
      fctnRC=$?
      if [[ $fctnRC -ne 0 ]]
      then
        return $fctnRC
      fi
    else
      echo "Service auditd restarted successfully" >> $swdPkgLog
    fi 
  fi

  echo . >> $swdPkgLog
  echo "Creating installation directory on /opt/tail2syslog." >> $swdPkgLog
  mkdir -p /opt/tail2syslog >> $swdPkgLog 2>&1
  fctnRC=$?
  if [[ $fctnRC -ne 0 ]]
  then
    echo "^^^ERROR: an error has ocurred creating installation on /opt/tail2syslog. The installation cannot continue.^^^"  >> $swdPkgLog
    RESTORE_FILE
    ERR
    fctnRC=$?
    if [[ $fctnRC -ne 0 ]]
    then
      return $fctnRC
    fi
  else
    echo "Installation folder was created on /opt/tail2syslog" >> $swdPkgLog
  fi 

	echo . >> $swdPkgLog
	echo "Copying the file \"$imgDir/70c-tail2syslog-package.zip\" to \"/opt/tail2syslog\" folder"  >> $swdPkgLog
	cp -f $imgDir/70c-tail2syslog-package.zip /opt/tail2syslog >> $swdPkgLog 2>&1
	fctnRC=$?
	if [[ $fctnRC -ne 0 ]]
	then 
		echo "^^^ERROR: An error has ocurred copying the file \"$imgDir/70c-tail2syslog-package.zip\" to \"/opt/tail2syslog\" folder.^^^"  >> $swdPkgLog
    RESTORE_FILE
		ERR
		fctnRC=$?
		if [[ $fctnRC -ne 0 ]]
		then
			return $fctnRC
		fi
	fi

	echo . >> $swdPkgLog
	echo "Accessing to \"/opt/tail2syslog\" folder "  >> $swdPkgLog
	cd /opt/tail2syslog >> $swdPkgLog 2>&1
	fctnRC=$?
	if [[ $fctnRC -ne 0 ]]
	then 
		echo "^^^ERROR: An error has ocurred accessing to \"/opt/tail2syslog\" folder.^^^"  >> $swdPkgLog
    RESTORE_FILE
		ERR
		fctnRC=$?
		if [[ $fctnRC -ne 0 ]]
		then
			return $fctnRC
		fi
	fi

	echo . >> $swdPkgLog
	echo "Uncompressing \"/opt/tail2syslog/70c-tail2syslog-package.zip\" file"  >> $swdPkgLog
	unzip -o 70c-tail2syslog-package.zip >> $swdPkgLog 2>&1
	fctnRC=$?
	if [[ $fctnRC -ne 0 ]]
	then 
		echo "^^^ERROR: An error has ocurred uncompressing \"/opt/tail2syslog/70c-tail2syslog-package.zip\" file.^^^"  >> $swdPkgLog
    RESTORE_FILE
		ERR
		fctnRC=$?
		if [[ $fctnRC -ne 0 ]]
		then
			return $fctnRC
		fi
	fi

	echo . >> $swdPkgLog
	echo "Copying \"/opt/tail2syslog/70c-tail2syslog-package/tail2syslog.pl\" file to \"/opt/tail2syslog\""  >> $swdPkgLog
	cp -f 70c-tail2syslog-package/tail2syslog.pl . >> $swdPkgLog 2>&1
	fctnRC=$?
	if [[ $fctnRC -ne 0 ]]
	then 
		echo "^^^ERROR: an error has ocurred copying \"/opt/tail2syslog/70c-tail2syslog-package/tail2syslog.pl\" file to \"/opt/tail2syslog\"^^^"  >> $swdPkgLog
    RESTORE_FILE
		ERR
		fctnRC=$?
		if [[ $fctnRC -ne 0 ]]
		then
			return $fctnRC
		fi
	fi

	echo . >> $swdPkgLog
	echo "Copying qradar.cfg file to \"/opt/tail2syslog\""  >> $swdPkgLog
	cp -f 70c-tail2syslog-package/sample-qradar.cfg ./qradar.cfg >> $swdPkgLog 2>&1
	fctnRC=$?
	if [[ $fctnRC -ne 0 ]]
	then 
		echo "^^^ERROR: An error has ocurred copying \"$imgDir/qradar.cfg\" file to \"/opt/tail2syslog\".^^^"  >> $swdPkgLog
    RESTORE_FILE
		ERR
		fctnRC=$?
		if [[ $fctnRC -ne 0 ]]
		then
			return $fctnRC
		fi
	fi

	echo . >> $swdPkgLog
	echo "Copying \"/opt/tail2syslog/70c-tail2syslog-package/File\" folder and its content to \"/opt/tail2syslog/File\""  >> $swdPkgLog
	cp -fr 70c-tail2syslog-package/File . >> $swdPkgLog 2>&1
	fctnRC=$?
	if [[ $fctnRC -ne 0 ]]
	then 
		echo "^^^ERROR: An error has ocurred copying \"/opt/tail2syslog/70c-tail2syslog-package/tail2syslog.pl\" file to \"/opt/tail2syslog\"^^^"  >> $swdPkgLog
    RESTORE_FILE
		ERR
		fctnRC=$?
		if [[ $fctnRC -ne 0 ]]
		then
			return $fctnRC
		fi
	fi

	echo . >> $swdPkgLog
	echo "Writing qradar.cfg file"  >> $swdPkgLog
	echo "Destinations=$tail2syslog_QradarIP" > ./qradar.cfg
	fctnRC=$?
	if [[ $fctnRC -ne 0 ]]
	then 
		echo "^^^ERROR: An error has ocurred updating qradar.cfg, the installation cannot continue.^^^"  >> $swdPkgLog
    RESTORE_FILE
		ERR
		fctnRC=$?
		if [[ $fctnRC -ne 0 ]]
		then
			return $fctnRC
		fi
	fi

	echo "Globs=$tail2syslog_Globs" >> ./qradar.cfg
	fctnRC=$?
	if [[ $fctnRC -ne 0 ]]
	then 
		echo "^^^ERROR: An error has ocurred updating qradar.cfg, the installation cannot continue.^^^"  >> $swdPkgLog
    RESTORE_FILE
		ERR
		fctnRC=$?
		if [[ $fctnRC -ne 0 ]]
		then
			return $fctnRC
		fi
	fi

	echo "ArchiveDir=$tail2syslog_ArchiveDir" >> ./qradar.cfg
	fctnRC=$?
	if [[ $fctnRC -ne 0 ]]
	then 
		echo "^^^ERROR: An error has ocurred updating qradar.cfg, the installation cannot continue.^^^"  >> $swdPkgLog
    RESTORE_FILE
		ERR
		fctnRC=$?
		if [[ $fctnRC -ne 0 ]]
		then
			return $fctnRC
		fi
	fi

	echo "DeletionThreshold=$tail2syslog_DeletionThreshold" >> ./qradar.cfg
	fctnRC=$?
	if [[ $fctnRC -ne 0 ]]
	then 
		echo "^^^ERROR: An error has ocurred updating qradar.cfg, the installation cannot continue.^^^"  >> $swdPkgLog
    RESTORE_FILE
		ERR
		fctnRC=$?
		if [[ $fctnRC -ne 0 ]]
		then
			return $fctnRC
		fi
	fi

	echo . >> $swdPkgLog
	echo "Settings execution rights to tail2syslog.pl file"  >> $swdPkgLog
	chmod +x tail2syslog.pl >> $swdPkgLog 2>&1
	fctnRC=$?
	if [[ $fctnRC -ne 0 ]]
	then 
		echo "^^^ERROR: An error has ocurred settings execution rights to tail2syslog.pl file.^^^"  >> $swdPkgLog
    RESTORE_FILE
		ERR
		fctnRC=$?
		if [[ $fctnRC -ne 0 ]]
		then
			return $fctnRC
		fi
	fi

	echo . >> $swdPkgLog
	echo "Executing \"/opt/tail2syslog/tail2syslog.pl\" file with the command line \" -i rh -a -f authpriv.notice -c /opt/tail2syslog/qradar.cfg -u -p 517 \"."  >> $swdPkgLog
	/opt/tail2syslog/tail2syslog.pl -i rh -a -f authpriv.notice -c /opt/tail2syslog/qradar.cfg -u -p 517 >> $swdPkgLog 2>&1
	fctnRC=$?
	if [[ $fctnRC -ne 0 ]]
	then 
		echo "^^^ERROR: An error has ocurred settings executing \"/opt/tail2syslog/tail2syslog.pl\" file with the command line \" -i rh -a -f authpriv.notice -c /opt/tail2syslog/qradar.cfg -u -p 517 \"^^^"  >> $swdPkgLog
    RESTORE_FILE
		ERR
		fctnRC=$?
		if [[ $fctnRC -ne 0 ]]
		then
			return $fctnRC
		fi
	fi

	echo . >> $swdPkgLog
	
  if [[ $already -eq 0 ]]
  then
    echo "Updating /etc/rc.d/rc.local" >> $swdPkgLog
    grep -v '^/opt/tail2syslog/tail2syslog.pl' /etc/rc.d/rc.local > temp_file
    echo "sleep 10" >> temp_file
    echo "/opt/tail2syslog/tail2syslog.pl -i rh -a -f authpriv.notice -c /opt/tail2syslog/qradar.cfg -u -p 517" >> temp_file
    cp temp_file /etc/rc.d/rc.local
    rc=$?
    if [[ $rc -ne 0 ]]
    then 
		  echo "^^^ERROR: An error has ocurred updating /etc/rc.d/rc.local, the installation cannot continue.^^^"  >> $swdPkgLog
      RESTORE_FILE
		  ERR
		  fctnRC=$?
		  if [[ $fctnRC -ne 0 ]]
		  then
			 return $fctnRC
		  fi
    fi
  else
    echo "The $swdPkgDesc is already installed and the file /etc/rc.d/rc.local will not be updated." >> $swdPkgLog
  fi

	echo . >> $swdPkgLog
  CREATE_SIG_FILE
  fctnRC=$?
  if [[ $fctnRC -ne 0 ]]
  then
    return $fctnRC
  fi
	
# ********** END INSTALLATION SECTION *****************************

# ********** EXECUTE ADMIN AFTER SCRIPT ***************************
  dir=`dirname $swdAdmAfter`

  # Verify directory script_path resides in
  VERIFY_FILE $dir root 0700
  admrc=$?

  if [[ "$admrc" != 0 ]]
  then
    if [[ "$admrc" = 1 ]]
    then
      echo "No customer specific administrative script ($swdAdmAfter) to execute." >> $swdPkgLog
    else
      echo "Incorrect permissions to execute $swdAdmAfter." >> $swdPkgLog
    fi
  else
    # Verify admin file (executable)
    VERIFY_FILE $swdAdmAfter root 0700
    admrc=$?

    if [[ "$admrc" != 0 ]]
    then
      if [[ "$admrc" = 1 ]]
      then
        echo "No customer specific administrative script ($swdAdmAfter) to execute." >> $swdPkgLog
      else
        echo "Incorrect permissions to execute $swdAdmAfter." >> $swdPkgLog
      fi
    else
      # Execute admin script
      $swdAdmAfter
      admrc=$?

      if [[ "$admrc" != 0 ]]
      then
        echo "ERROR: Executing $swdAdmAfter administrative script, rc = $admrc" >> $swdPkgLog
        admrc=3
      else
        echo "Administrative script $swdAdmAfter executed successfully." >> $swdPkgLog
      fi
    fi
  fi
# ********** END EXECUTE ADMIN AFTER SCRIPT ***********************

# ********** CHECK RETURN CODES ***********************************
  if [[ "$rc" != 0 ]]
  then
    echo "^^^ERROR: Install command failed; aborting the install.^^^" >> $swdPkgLog
    ERR
    fctnRC=$?
    if [[ $fctnRC -ne 0 ]]
    then
      return $fctnRC
    fi
  elif [[ "$admrc" > 1 ]]
    then
      echo "^^^ERROR: Executing $swdAdmAfter administrative script, rc = $admrc^^^" >> $swdPkgLog
      ADMIN_SCRIPT_FAILED
      fctnRC=$?
      if [[ $fctnRC -ne 0 ]]
      then
        return $fctnRC
      fi
  fi
# ********** END CHECK RETURN CODES *******************************

# ********** POST-INSTALLATION CONFIGURATION **********************

# ********** END POST-INSTALLATION CONFIGURATION ******************
fi
###################################################################
#*#*#* END INSTALL SECTION *#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#
###################################################################

###################################################################
#*#*#* VERIFY INSTALL CHECK ## REQUIRED FOR ALL PACKAGES *#*#*#*#*#
###################################################################
if [[ "$swdVerifyChk" = "Y" ]] || [[ "$swdVerifyChk" = "YES" ]]
then
  echo . >> $swdPkgLog
  echo "Beginning verification installation check..." >> $swdPkgLog
  #This is the normal installation verification.  All successful installation verification should take place in the
  #INSTAL SECTION instead of in this section.  This section should be coded to check and see whether or not the application is installed on the system.
  #You can use the same concept as your code in the already installed section, but do not perform a check for an esd created signature file
  #because a customer could already have this application installed by some other means than the ESD package.

  echo . >> $swdPkgLog
  #If there is no normal installation verification AND there is no customer specific installation verification listed in the requirements,
  #make sure to uncomment "#NO_INSTALL_VERIFICATION_CHK_AVAILABLE" and related fctnRC check.
  #NO_INSTALL_VERIFICATION_CHK_AVAILABLE
  #fctnRC=$?
  #if [[ $fctnRC -ne 0 ]]
  #then
  #  return $fctnRC
  #fi

  ##Verify install check goes here.##
	echo "Checking if /var/.SWDist_Sig/$sigfile exist..." >> $swdPkgLog
	if [[ ! -f /var/.SWDist_Sig/$sigfile ]]
	then
		echo "^^^ERROR: $swdPkgDesc was NOT found installed on the system.^^^" >> $swdPkgLog
		ERR
		fctnRC=$?
		if [[ $fctnRC -ne 0 ]]
		then
			return $fctnRC
		fi
	else
		echo "/var/.SWDist_Sig/$sigfile file found. Package $swdPkgDesc is installed." >> $swdPkgLog
	fi
  #If there is a verification check and the application is not found installed on the system, please use this error message and related fctnRC check.
  #echo "^^^ERROR: $swdPkgDesc was NOT found installed on the system.^^^" >> $swdPkgLog
  #  ERR
  #  fctnRC=$?
  #  if [[ $fctnRC -ne 0 ]]
  #  then
  #    return $fctnRC
  #  fi
fi
###################################################################
#*#*#* END VERIFY INSTALL CHECK *#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*
###################################################################

###################################################################
#*#*#* CURRENT VERSION CHECK ## REQUIRED FOR ALL PACKAGES *#*#*#*#*
###################################################################
if [[ "$swdCurVerChk" = "Y" ]] || [[ "$swdCurVerChk" = "YES" ]]
then
  echo . >> $swdPkgLog
  echo "Beginning current version check..." >> $swdPkgLog

  curVerFnd=""

  #Determine current version in this section if you have made an effort to discover the current version in any of the code above.
  #If there is no current version check in your code, make sure to uncomment "#NO_CURRENT_VERSION_CHK_AVAILABLE" and related fctnRC check.
  NO_CURRENT_VERSION_CHK_AVAILABLE
  fctnRC=$?
  if [[ $fctnRC -ne 0 ]]
  then
    return $fctnRC
  fi

  ##Current version check goes here.##

  #If there is a current version check, and you do find a current version on the system, please use the following variable and message.
  #echo "^^^VERSION: $curVerFnd^^^ >> $swdPkgLog
  #  OK_CUR_VER_CHK
  #  fctnRC=$?
  #  return $fctnRC

  #If there is a current version check, but no current version was found, please use the following message and related fctnRC check.
  #echo "^^^ERROR: No current version found for $swdPkgDesc.^^^" >> $swdPkgLog
  #  ERR
  #  fctnRC=$?
  #  if [[ $fctnRC -ne 0 ]]
  #  then
  #    return $fctnRC
  #  fi
fi
###################################################################
#*#*#* END CURRENT VERSION CHECK *#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#
###################################################################
OK
